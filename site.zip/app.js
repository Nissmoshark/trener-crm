// «Світлиця» — сімейний додаток: світло й інвертор, тривоги, зарядка ЖК, покупки, події
(function () {
  const API_URL = (window.ENERGY_API || "").trim();
  const DEMO = !API_URL;
  // iOS ігнорує user-scalable=no — блокуємо щипок, щоб екран не «плив»
  for (const ev of ["gesturestart", "gesturechange"]) document.addEventListener(ev, (e) => e.preventDefault(), { passive: false });
  const $ = (s, el = document) => el.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const pad = (n) => String(n).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const D = (day) => new Date(day + "T00:00:00");
  const addDays = (day, n) => { const d = D(day); d.setDate(d.getDate() + n); return iso(d); };
  const today = () => iso(new Date());
  const hm = (ms) => { const d = new Date(ms); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const WD = ["Нд", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
  const WDL = ["неділя", "понеділок", "вівторок", "середа", "четвер", "пʼятниця", "субота"];
  const MON = ["січня", "лютого", "березня", "квітня", "травня", "червня", "липня", "серпня", "вересня", "жовтня", "листопада", "грудня"];
  const MONN = ["Січень", "Лютий", "Березень", "Квітень", "Травень", "Червень", "Липень", "Серпень", "Вересень", "Жовтень", "Листопад", "Грудень"];
  const dLong = (day) => { const d = D(day); return `${d.getDate()} ${MON[d.getMonth()]}`; };
  const dayLabel = (day) => { const t = today(); return day === t ? "Сьогодні" : day === addDays(t, 1) ? "Завтра" : `${WD[D(day).getDay()]}, ${dLong(day)}`; };
  const num = (x, dig = 0) => (Number(x) || 0).toLocaleString("uk-UA", { minimumFractionDigits: dig, maximumFractionDigits: dig }).replace(/ /g, " ");
  const dur = (min) => { min = Math.max(0, Math.round(min)); const h = Math.floor(min / 60), m = min % 60; return h ? `${h} год${m ? ` ${m} хв` : ""}` : `${m} хв`; };
  const durShort = (min) => { min = Math.max(0, Math.round(min)); const h = Math.floor(min / 60), m = min % 60; return h ? `${h}:${pad(m)}` : `${m} хв`; };
  // «2,2 кВт» → число великим, одиниця дрібно (щоб влазило в плитку)
  const unitSm = (x) => { const i = String(x).lastIndexOf(" "); return i > 0 && /^[кК]?[ВW]/.test(String(x).slice(i + 1)) ? `${String(x).slice(0, i)}<em class="u">${String(x).slice(i + 1)}</em>` : x; };
  const watts = (w) => (w == null ? "—" : Math.abs(w) >= 1000 ? `${num(w / 1000, 1)} кВт` : `${Math.round(w)} Вт`);
  const REGIONS = ["АР Крим", "Волинська обл.", "Вінницька обл.", "Дніпропетровська обл.", "Донецька обл.", "Житомирська обл.",
    "Закарпатська обл.", "Запорізька обл.", "Івано-Франківська обл.", "м. Київ", "Київська обл.", "Кіровоградська обл.", "Луганська обл.",
    "Львівська обл.", "Миколаївська обл.", "Одеська обл.", "Полтавська обл.", "Рівненська обл.", "м. Севастополь", "Сумська обл.",
    "Тернопільська обл.", "Харківська обл.", "Херсонська обл.", "Хмельницька обл.", "Черкаська обл.", "Чернівецька обл.", "Чернігівська обл."];
  const CAT_ORDER = ["Овочі й фрукти", "Молочне й яйця", "Хліб", "М'ясо й риба", "Бакалія", "Солодке й снеки", "Напої", "Побутове", "Аптека", "Інше"];
  const REP = { none: "", weekly: "щотижня", monthly: "щомісяця", yearly: "щороку" };
  const REMINDS = [[0, "У момент"], [30, "За 30 хв"], [60, "За годину"], [120, "За 2 год"], [1440, "За день"], [10080, "За тиждень"]];
  const isRaid = (c) => c === "A" || c === "R" || c === "Y";
  const sv = (p, extra = "") => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"${extra}>${p}</svg>`;
  const ICON = {
    home: sv('<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-5h4v5"/>'),
    cart: sv('<path d="M3 4h2l2.4 11h10.2L20 8H6.2"/><circle cx="9.5" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/>'),
    cal: sv('<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>'),
    more: sv('<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>'),
    siren: sv('<path d="M7 18v-6a5 5 0 0110 0v6"/><path d="M5 21h14v-3H5zM12 3v1M4.2 6.2l.8.8M19.8 6.2l-.8.8M2 12h1M21 12h1"/>'),
    bolt: sv('<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>'),
    users: sv('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.2-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 010 6.8M18.5 14.8c1.7.8 2.7 2.5 3 5.2"/>'),
    gear: sv('<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>'),
    socket: sv('<rect x="3" y="3" width="18" height="18" rx="5"/><path d="M9.5 9v2.5M14.5 9v2.5M8.5 14h7"/>'),
    tg: sv('<path d="M21 4L3 11l6 2 2 6 3-4 5 4z"/><path d="M9 13l12-9"/>'),
    pin: sv('<path d="M12 21s-7-6.2-7-11.5a7 7 0 0114 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>'),
    key: sv('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>'),
    out: sv('<path d="M15 4h4v16h-4M10 17l-5-5 5-5M5 12h11"/>'),
    plus: sv('<path d="M12 5v14M5 12h14"/>', ' stroke-width="2.4"'),
    check: sv('<path d="M5 12.5l4.5 4.5L19 7.5"/>', ' stroke-width="2.6"'),
    x: sv('<path d="M6 6l12 12M18 6L6 18"/>'),
    plug: sv('<path d="M9 2v5M15 2v5M6 7h12v4a6 6 0 01-12 0zM12 17v5"/>'),
    rep: sv('<path d="M4 11a8 8 0 0114-4.5L20 8M20 13a8 8 0 01-14 4.5L4 16"/><path d="M20 3v5h-5M4 21v-5h5"/>'),
    left: sv('<path d="M15 18l-6-6 6-6"/>', ' stroke-width="2.2"'),
    right: sv('<path d="M9 18l6-6-6-6"/>', ' stroke-width="2.2"'),
  };

  let token = ""; try { token = localStorage.getItem("energy-token") || ""; } catch {}
  async function call(action, body = {}) {
    if (DEMO) return window.DemoBackend.call(action, body);
    let r;
    try { r = await fetch(API_URL, { method: "POST", headers: { "content-type": "application/json", ...(token ? { authorization: "Bearer " + token } : {}) }, body: JSON.stringify({ action, ...body, ...(token ? { _app: location.origin + location.pathname } : {}) }) }); }
    catch { return { ok: false, error: "Немає звʼязку з сервером" }; }
    const j = await r.json().catch(() => ({ ok: false, error: "Помилка сервера" }));
    if (j.error === "auth") { token = ""; try { localStorage.removeItem("energy-token"); } catch {} showLogin(); }
    else if ((j.ok && j.me && j.me.needs_credentials) || /задайте номер телефону/.test(j.error || "")) { showCredentials(j.me || st.me); return { ok: false, error: "auth" }; }
    return j;
  }
  // Графік ДТЕК — окрема функція сервера
  const DTEK_URL = (window.DTEK_API || API_URL.replace(/\/energy\/?$/, "/svit-dtek")).trim();
  async function callDtek(action, body = {}) {
    if (DEMO) return window.DemoBackend.call(action, body);
    try { const r = await fetch(DTEK_URL, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + token }, body: JSON.stringify({ action, ...body }) }); return await r.json(); }
    catch { return { ok: false, error: "Немає звʼязку з сервером" }; }
  }
  // Витрати сімʼї — окрема функція сервера
  const MONEY_URL = (window.MONEY_API || API_URL.replace(/\/energy\/?$/, "/svit-money")).trim();
  async function callMoney(action, body = {}) {
    if (DEMO) return window.DemoBackend.call(action, body);
    let r;
    try { r = await fetch(MONEY_URL, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + token }, body: JSON.stringify({ action, ...body }) }); }
    catch { return { ok: false, error: "Немає звʼязку з сервером" }; }
    const j = await r.json().catch(() => ({ ok: false, error: "Помилка сервера" }));
    if (j.error === "auth") { token = ""; try { localStorage.removeItem("energy-token"); } catch {} showLogin(); }
    return j;
  }
  async function must(action, body) { const j = await call(action, body); if (!j.ok) { if (j.error !== "auth") toast(j.error || "Помилка"); throw new Error(j.error); } return j; }
  function toast(m) { const t = document.createElement("div"); t.className = "toast"; t.role = "status"; t.textContent = m; document.body.appendChild(t); setTimeout(() => t.remove(), 2800); }

  const st = { tab: "home", shopView: "list", spendMonth: today().slice(0, 7), spendCat: null, light: "out", more: "menu", period: "week", anchor: today(), month: today().slice(0, 7), settings: {}, me: {}, shopLeft: 0, shop: null, ev: null };
  const root = document.getElementById("app");
  const isAdmin = () => st.me.role === "admin";

  function shell(inner) {
    root.innerHTML = `${DEMO ? '<div class="demo">Демо з вигаданими даними. Справжні — після підключення</div>' : ""}
      <main class="app">${inner}</main>
      <nav class="nav" aria-label="Розділи"><div class="nav-in">
        ${[["home", "Дім", ICON.home], ["shop", "Покупки", ICON.cart], ["alerts", "Тривоги", ICON.siren], ["light", "Світло", ICON.bolt], ["more", "Ще", ICON.more]]
          .map(([k, l, i]) => `<button data-tab="${k}" ${st.tab === k ? 'aria-current="page"' : ""}>${i}${k === "shop" && st.shopLeft ? `<em class="badge">${st.shopLeft}</em>` : ""}${l}</button>`).join("")}
      </div></nav>`;
  }
  const back = (to) => `<button class="icon back" data-act="${to}" aria-label="Назад">${ICON.left}</button>`;
  root.addEventListener("click", (e) => {
    const t = e.target.closest("[data-tab],[data-act]"); if (!t) return;
    if (t.dataset.tab) { st.tab = t.dataset.tab; if (st.tab === "more") st.more = "menu"; render(); window.scrollTo(0, 0); return; }
    const fn = H[t.dataset.act]; if (fn) fn(t.dataset, t);
  });

  // ───── Повтори подій (ті самі правила, що на сервері) ─────
  const dn = (d) => Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10)) / 86400000;
  const nd = (n) => new Date(n * 86400000).toISOString().slice(0, 10);
  function occDays(ev, from, to) {
    const out = [], base = ev.day, push = (d) => { if (d >= base && d >= from && d <= to) out.push(d); };
    if (to < base) return out;
    if (ev.rep === "none") push(base);
    else if (ev.rep === "weekly") { const k = Math.max(0, Math.floor((dn(from) - dn(base)) / 7)); for (let n = dn(base) + k * 7; n <= dn(to); n += 7) push(nd(n)); }
    else {
      const bd = +base.slice(8, 10), bm = +base.slice(5, 7); let y = +from.slice(0, 4), m = +from.slice(5, 7);
      while (`${y}-${pad(m)}` <= to.slice(0, 7)) {
        if (ev.rep === "monthly" || m === bm) push(`${y}-${pad(m)}-${pad(Math.min(bd, new Date(Date.UTC(y, m, 0)).getUTCDate()))}`);
        if (++m > 12) { m = 1; y++; }
      }
    }
    return out;
  }
  window.DimOcc = occDays;

  // Смуга доби: 96 клітинок по 15 хв
  function stripFromSamples(day, samples) {
    const t0 = D(day).getTime(), now = Date.now(), cells = [];
    for (let i = 0; i < 96; i++) {
      const a = t0 + i * 900000, b = a + 900000;
      if (a > now) { cells.push(""); continue; }
      const ss = samples.filter((s) => { const t = Date.parse(s.ts); return t >= a - 150000 && t < b + 150000; });
      if (!ss.length) { cells.push(""); continue; }
      cells.push(ss.filter((s) => !s.grid_on).length * 2 >= ss.length ? "off" : "on");
    }
    return cells;
  }
  function stripFromOutages(day, outages, nowMs) {
    const t0 = D(day).getTime(), cells = [];
    for (let i = 0; i < 96; i++) {
      const a = t0 + i * 900000, b = a + 900000;
      if (a > nowMs) { cells.push(""); continue; }
      let off = 0;
      for (const o of outages) { const s = Date.parse(o.started_at), e = o.ended_at ? Date.parse(o.ended_at) : nowMs; off += Math.max(0, Math.min(b, e) - Math.max(a, s)); }
      cells.push(off * 2 >= 900000 ? "off" : "on");
    }
    return cells;
  }
  const stripHtml = (cells, label) => `<div class="strip" role="img" aria-label="${esc(label)}">${cells.map((c) => `<i class="${c}"></i>`).join("")}</div>`;
  const hoursAxis = '<div class="strip-x"><span>0</span><span>6</span><span>12</span><span>18</span><span>24</span></div>';

  // ───── Графік ДТЕК ─────
  function schedCells(d) {
    const cells = Array(96).fill("on");
    for (const x of d.slots) for (let i = Math.floor(x.s / 15); i < Math.ceil(x.e / 15) && i < 96; i++) cells[i] = x.t === "off" ? "off" : cells[i] === "off" ? "off" : "maybe";
    return cells;
  }
  function dtekCard(t, s, fact) {
    if (!t) return "";
    if (!t.group) return `<section class="panel"><h2>Графік ДТЕК</h2><p class="note" style="margin:0 0 12px">Вкажіть свою чергу — додаток покаже графік, попередить про відключення й порахує, чи вистачить АКБ.</p>${isAdmin() ? '<button class="btn" data-act="goMore" data-p="settings">Вибрати чергу</button>' : '<p class="note" style="margin:0">Чергу вибирає адміністратор у налаштуваннях.</p>'}</section>`;
    const now = Date.now(), fc = t.forecast, iv = t.current || t.next;
    const tomorrowLbl = (ms) => (new Date(ms).toDateString() !== new Date().toDateString() ? "завтра " : "");
    const need = iv ? (iv.b - Math.max(iv.a, now)) / 60000 : 0;
    const enough = fc && iv ? fc.hours * 60 >= need * 1.15 : null;
    // «6:42 год» / «45 хв» — коротко, щоб влазило в плитку
    const dv = (min) => { min = Math.max(0, Math.round(min)); const h = Math.floor(min / 60), m = min % 60; return h ? `${h}${m ? ":" + pad(m) : ""}<em class="u">год</em>` : `${m}<em class="u">хв</em>`; };
    const inTxt = (ms) => (tomorrowLbl(ms) ? "завтра" : `за ${durShort((ms - now) / 60000)}`);
    const tiles = [
      t.current ? ["Світло о", hm(t.current.b), inTxt(t.current.b), "on"]
        : t.next ? ["Вимкнуть о", hm(t.next.a), inTxt(t.next.a), "off"]
        : ["Відключень", "немає", "найближчим часом", "on"],
      iv ? ["Без світла", dv(need), `до ${hm(iv.b)}`, ""] : ["Без світла", "—", "", ""],
      fc ? ["Запас АКБ", dv(fc.hours * 60), enough == null ? `${fc.soc}% заряду` : enough ? "✅ вистачить" : "⚠️ замало", enough === false ? "warn" : ""] : ["Запас АКБ", "—", "немає даних", ""],
    ];
    const nowCell = (() => { const d = new Date(); return Math.floor((d.getHours() * 60 + d.getMinutes()) / 15); })();
    const days = t.days.map((d) => {
      const lbl = d.date === today() ? "Сьогодні" : "Завтра";
      if (!d.slots.length && d.status !== "ScheduleApplies") return `<div class="sday"><div class="sday-h"><b>${lbl}</b><small>${esc(t.status_ua[d.status] || d.status)}</small></div></div>`;
      const off = d.slots.filter((x) => x.t === "off").reduce((a, x) => a + x.e - x.s, 0);
      const cells = schedCells(d), isToday = d.date === today();
      if (isToday) cells[nowCell] += " now";
      const head = `<div class="sday-h"><b>${lbl}</b><small>${off ? `за графіком без світла ${dur(off)}` : "без відключень"}${d.status === "EmergencyShutdowns" ? " · ⚠️ екстрені" : ""}</small></div>`;
      if (!isToday || !fact) return `<div class="sday">${head}${stripHtml(cells, `${lbl}: графік`)}</div>`;
      const fc = fact.cells.slice(); fc[nowCell] = (fc[nowCell] || "") + " now";
      return `<div class="sday">${head}
        <div class="cmp"><span>ДТЕК</span>${stripHtml(cells, "Сьогодні: графік ДТЕК")}</div>
        <div class="cmp"><span>Факт</span>${stripHtml(fc, "Сьогодні: фактично за інвертором")}</div>
        <div class="cmp-note">фактично без світла ${dur(fact.off)}</div></div>`;
    }).join("");
    const noTomorrow = t.days.length === 1 ? '<p class="sday-none">Завтра — графік ще не опубліковано</p>' : "";
    return `<section class="panel dtek"><h2 class="row"><span>Графік ДТЕК · ${esc(t.group)}</span><em>${t.at ? hm(t.at) : ""}</em></h2>
      <div class="dtiles">${tiles.map(([l, v, sub, c]) => `<div class="dtile ${c}"><span>${l}</span><b>${v}</b><small>${sub}</small></div>`).join("")}</div>
      ${days}${days ? '<div class="strip-x"><span>0</span><span>6</span><span>12</span><span>18</span><span>24</span></div>' : ""}${noTomorrow}
      ${t.error ? `<p class="err" style="margin:8px 0 0">${esc(t.error)}</p>` : ""}</section>`;
  }

  // ───── Дім ─────
  async function renderHome() {
    shell('<div class="head"><h1>Світлиця</h1></div><div class="empty">Завантаження…</div>');
    const j = await must("dashboard");
    st.settings = j.settings; st.me = j.me; st.shopLeft = j.home.shop_left;
    autoLocate().then((r) => { if (r && r.ok && st.tab === "home") renderHome().catch(() => {}); });
    wxGet(wxPlace()).then((x) => { const el = $("#wx-card"); if (el) el.outerHTML = wxCard(x); }).catch(() => {});
    callMoney("money", { month: today().slice(0, 7) }).then((m) => {
      const el = $("#spend-card"); if (!el || !m.ok) return;
      const P = m.planner; if (!m.family.some((f) => f.connected) && !P.accounts.length && !P.budgets.length) return;
      const nx = P.plans.filter((p) => !p.paid && p.kind === "expense").sort((a, b) => a.due.localeCompare(b.due))[0];
      const bt = P.budget_total, bs = P.budgets.reduce((s, b) => s + b.spent, 0);
      el.outerHTML = `<section class="panel tap" data-act="goSpend"><h2 class="row"><span>💳 Гроші</span><em>${MONN[new Date().getMonth()].toLowerCase()}</em></h2>
        <div class="mrow"><div><small>На рахунках</small><b>${UAH(P.total)}</b></div>${P.forecast ? `<div><small>Прогноз на кінець</small><b class="${P.forecast.end < 0 ? "neg" : ""}">${UAH(P.forecast.end)}</b></div>` : ""}<div><small>Витрачено</small><b>${UAH(m.total)}</b></div></div>
        ${bt ? bar(bs, bt, pctCls((bs / bt) * 100)) : ""}
        ${nx ? `<p class="note" style="margin:8px 0 0">🔔 ${esc(nx.title)} — ${UAH(nx.amount)}, ${ddmm(nx.due)}</p>` : ""}</section>`;
    }).catch(() => {});
    const factCells = j.last ? stripFromSamples(today(), j.samples) : null;
    const fact = factCells ? { cells: factCells, off: (j.today && j.today.outage_min) || 0 } : null;
    callDtek("dtek").then((t) => { const el = $("#dtek-card"); if (el && t.ok) el.outerHTML = dtekCard(t, t.settings, fact); }).catch(() => {});
    const s = j.settings, r = j.last, h = j.home;
    let energy = "", todayPanel = "";
    if (!r) {
      energy = `<section class="panel"><h2>Інвертор ще не підключено</h2><p class="note" style="margin:0 0 12px">${isAdmin() ? "Введіть логін і пароль від SmartESS — стан світла й АКБ зʼявиться тут за хвилину." : "Адміністратор підключить його в налаштуваннях."}</p>${isAdmin() ? '<button class="btn lamp" data-act="goMore" data-p="settings">Підключити</button>' : ""}</section>`;
    } else {
      const off = !!j.open;
      const sinceMin = off ? (j.now - Date.parse(j.open.started_at)) / 60000 : j.last_outage ? (j.now - Date.parse(j.last_outage.ended_at)) / 60000 : null;
      const soc = r.soc == null ? null : Math.round(r.soc);
      const low = soc != null && soc <= (s.low_soc || 25);
      let note = "";
      if (soc != null && r.batt_in_w > 30) note = `Заряджається · ${watts(r.batt_in_w)}`;
      else if (soc != null && r.batt_out_w > 30) {
        note = `Розряджається · ${watts(r.batt_out_w)}`;
        if (s.batt_kwh && r.load_w > 30) { const hh = (Math.max(0, soc - 10) / 100) * s.batt_kwh * 1000 / r.load_w; note += ` · вистачить ≈ ${dur(hh * 60)}`; }
      }
      energy = `<section class="state ${off ? "off" : "on"}" aria-live="polite">
          <span class="glow"></span>
          <div class="big">${off ? "Світла немає" : "Світло є"}</div>
          <div class="since">${off ? `вже ${dur(sinceMin)}, з ${hm(Date.parse(j.open.started_at))}` : sinceMin != null ? `${sinceMin < 1440 ? `повернулось ${dur(sinceMin)} тому` : `останнє відключення ${dLong(iso(new Date(Date.parse(j.last_outage.ended_at))))}`}` : `мережа ${Math.round(r.grid_v || 0)} В`}</div>
          ${soc != null ? `<div class="batt"><div class="cells" aria-label="Заряд АКБ ${soc}%">${Array.from({ length: 10 }, (_, i) => `<i class="${i < Math.round(soc / 10) ? "f" : ""} ${low ? "low" : ""}"></i>`).join("")}</div><b>${soc}%</b></div>
          <div class="batt-note">${esc(note || "АКБ у режимі очікування")}</div>` : ""}
        </section>
        <div class="flows">
          <div class="flow"><span>Мережа</span><b>${unitSm(r.grid_on ? `${Math.round(r.grid_v || 0)} В` : "немає")}</b></div>
          <div class="flow"><span>Будинок</span><b>${unitSm(watts(r.load_w))}</b></div>
          <div class="flow"><span>Сонце</span><b>${unitSm(watts(r.pv_w))}</b></div>
          <div class="flow"><span>АКБ</span><b>${unitSm(r.batt_in_w > 30 ? "+" + watts(r.batt_in_w) : r.batt_out_w > 30 ? "−" + watts(r.batt_out_w) : "0")}</b></div>
        </div>`;
      const t = j.today || {};
      todayPanel = `<section class="panel">
          <h2>Світло сьогодні</h2>
          ${stripHtml(stripFromSamples(today(), j.samples), "Світло сьогодні по годинах")}${hoursAxis}
          <div class="kpis">
            <div class="kpi"><b>${dur(t.outage_min || 0)}</b><span>без світла</span></div>
            <div class="kpi"><b>${num(t.grid_kwh || 0, 1)}</b><span>кВт·год з мережі</span></div>
            <div class="kpi"><b>${num(t.grid_cost || 0)} ₴</b><span>за світло</span></div>
          </div>
        </section>`;
    }
    const age = r ? Math.round((j.now - Date.parse(r.ts)) / 60000) : null;
    const evRows = h.events.map((e) => `<button class="erow" data-act="openEvent" data-id="${e.id}"><span class="when">${e.day === today() ? (e.tm || "весь день") : `${dayLabel(e.day)}${e.tm ? `<small>${e.tm}</small>` : ""}`}</span><span class="what"><b>${esc(e.title)}</b>${e.who ? `<small>${esc(e.who)}</small>` : ""}</span></button>`).join("");
    shell(`
      <div class="head"><div><h1>Світлиця</h1><small>${esc(st.me.name)}${age != null ? ` · ${age <= 1 ? "дані щойно" : `дані ${age} хв тому`}` : ""}</small></div>${r ? '<button class="ghost" data-act="refresh">Оновити</button>' : ""}</div>
      ${raidBanner(j.alerts, j.now)}
      <a class="dronelink" href="https://map.ukrainealarm.com" target="_blank" rel="noopener">🛰 Рух дронів і ракет на карті ›</a>
      <div id="wx-card"></div>
      ${energy}
      <div id="dtek-card"></div>
      ${chargeCard(h.charging)}
      <div id="spend-card"></div>
      <section class="panel tap" data-tab="shop">
        <h2 class="row"><span>${ICON.cart}Покупки</span><em>${h.shop_left ? `купити ${h.shop_left}` : "усе куплено"}</em></h2>
        ${h.shop_left ? `<div class="pchips">${h.shop_preview.map((n) => `<span>${esc(n)}</span>`).join("")}${h.shop_left > h.shop_preview.length ? `<span class="more">+${h.shop_left - h.shop_preview.length}</span>` : ""}</div>` : '<p class="note" style="margin:0">Список порожній — додайте, що треба купити.</p>'}
      </section>
      <section class="panel">
        <h2 class="row"><span>${ICON.cal}Найближчі події</span><button class="link" data-act="goMore" data-p="events">усі</button></h2>
        ${evRows ? `<div class="elist">${evRows}</div>` : '<p class="note" style="margin:0">На тиждень нічого не заплановано.</p>'}
        ${h.power.length ? `<div class="powerbox"><b>${ICON.plug} Коли дадуть світло:</b> ${h.power.map((p) => esc(p.title)).join(", ")}</div>` : ""}
      </section>
      ${todayPanel}
      ${s.last_error && r ? `<p class="err">Остання помилка звʼязку з інвертором: ${esc(s.last_error)}</p>` : ""}`);
  }

  const thrLine = (st) => (st && st.threat_names && st.threat_names.length ? `<span class="thr">⚠️ ${esc(st.threat_names.join(", "))}</span>` : "");
  function raidBanner(al, nowMs) {
    if (!al || !al.has_token || al.state.length !== 27) return `<button class="raid" data-tab="alerts"><i></i><span class="rt">Статус тривоги<small>${al && al.error ? esc(al.error) : "дані ще не надійшли"}</small></span><small>›</small></button>`;
    // якщо я зараз не вдома — показуємо тривогу там, де я
    const me = al.zones && al.zones.family.find((f) => f.me);
    if (me && me.place && me.place !== "Київ" && me.status) {
      const s = me.status, m = s.since ? (nowMs - Date.parse(s.since)) / 60000 : 0;
      return `<button class="raid ${s.active ? "on" : ""} ${s.active && !s.red ? "y" : ""}" data-tab="alerts"><i></i><span class="rt">${s.active ? esc(s.kinds[0] || "Тривога") : "Тривоги немає"}<small>📍 ${esc(me.place)}</small>${thrLine(s)}</span><small>${s.active ? dur(m) : s.near ? `в області: ${s.near}` : ""}</small></button>`;
    }
    const c = al.state[al.region], hs = al.zones && al.zones.home.status;
    if (isRaid(c)) {
      const m = al.open ? (nowMs - Date.parse(al.open.started_at)) / 60000 : 0;
      return `<button class="raid on ${c === "Y" ? "y" : ""}" data-tab="alerts"><i></i><span class="rt">Тривога · ${esc(al.region_name)}${thrLine(hs)}</span><small>${al.open ? dur(m) : ""}</small></button>`;
    }
    const others = [...al.state].filter(isRaid).length;
    return `<button class="raid" data-tab="alerts"><i></i><span class="rt">Тривоги немає · ${esc(al.region_name)}</span><small>${others ? `тривога в ${others} обл.` : "по Україні тихо"}</small></button>`;
  }
  // місце члена сімʼї: автоматично при відкритті (якщо вже дозволили), не частіше ніж раз на 10 хв
  function autoLocate(force = false) {
    let on = false, last = 0; try { on = localStorage.getItem("svit-autoloc") === "1"; last = +localStorage.getItem("svit-autoloc-at") || 0; } catch {}
    if (!navigator.geolocation || DEMO || (!force && (!on || Date.now() - last < 10 * 60000))) return Promise.resolve(null);
    return new Promise((ok) => navigator.geolocation.getCurrentPosition(async (p) => {
      try { localStorage.setItem("svit-autoloc", "1"); localStorage.setItem("svit-autoloc-at", String(Date.now())); } catch {}
      ok(await call("loc_share", { lat: p.coords.latitude, lon: p.coords.longitude, accuracy: p.coords.accuracy }));
    }, (e) => { if (force) toast(e.code === 1 ? "Дозвольте доступ до геолокації в браузері" : "Не вдалося визначити місце"); ok(null); }, { enableHighAccuracy: false, timeout: 15000, maximumAge: 5 * 60000 }));
  }

  // ───── Покупки ─────
  const shopHead = (sub = "&nbsp;") => `<div class="head"><div><h1>Покупки</h1><small id="shop-sub">${sub}</small></div></div>
    <div class="seg" role="group" aria-label="Розділ"><button data-act="shopView" data-v="list" aria-pressed="${st.shopView === "list"}">Список</button><button data-act="shopView" data-v="spend" aria-pressed="${st.shopView === "spend"}">Гроші</button></div>`;
  async function renderShop() {
    if (st.shopView === "spend") return renderSpend();
    shell(`${shopHead()}
      <form class="addbar" id="shop-form" autocomplete="off">
        <input id="shop-in" placeholder="Що купити? Можна кілька через кому" aria-label="Що купити" enterkeyhint="done">
        <button class="addbtn" aria-label="Додати">${ICON.plus}</button>
      </form>
      <div id="slist"><div class="empty">Завантаження…</div></div>`);
    $("#shop-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const inp = $("#shop-in"), text = inp.value.trim(); if (!text) return;
      const j = await call("shop_add", { text });
      if (!j.ok) { toast(j.error); return; }
      inp.value = ""; if (!j.added) toast("Це вже є у списку");
      drawShop(j); inp.focus();
    });
    drawShop(await must("shop_list"));
  }
  function drawShop(j) {
    st.shop = j;
    const box = $("#slist"); if (!box) return;
    const open = j.items.filter((i) => !i.bought_at), done = j.items.filter((i) => i.bought_at).sort((a, b) => Date.parse(b.bought_at) - Date.parse(a.bought_at));
    st.shopLeft = open.length;
    const badge = document.querySelector('.nav [data-tab="shop"] .badge');
    if (badge) badge.textContent = open.length || "";
    $("#shop-sub").textContent = open.length ? `купити ${open.length}` : "усе куплено";
    const groups = CAT_ORDER.map((c) => [c, open.filter((i) => i.cat === c)]).filter(([, l]) => l.length);
    const item = (i) => `<li class="${i.bought_at ? "done" : ""}">
        <button class="tick" data-act="shopToggle" data-id="${i.id}" aria-label="${i.bought_at ? "Повернути в список" : "Куплено"}: ${esc(i.name)}">${ICON.check}</button>
        <span class="nm"><span class="t">${esc(i.name)}</span><small>${i.bought_at ? `${esc(i.bought_name || "")} · ${dayLabel(iso(new Date(Date.parse(i.bought_at)))) === "Сьогодні" ? hm(Date.parse(i.bought_at)) : dayLabel(iso(new Date(Date.parse(i.bought_at))))}` : i.added_name && i.added_name !== st.me.name ? esc(i.added_name) : ""}</small></span>
        ${i.bought_at ? "" : `<button class="del" data-act="shopDel" data-id="${i.id}" aria-label="Видалити ${esc(i.name)}">${ICON.x}</button>`}
      </li>`;
    box.innerHTML = `
      ${j.frequent.length ? `<div class="freq"><span>Часто купуєте:</span>${j.frequent.map((n) => `<button data-act="shopQuick" data-n="${esc(n)}">+ ${esc(n)}</button>`).join("")}</div>` : ""}
      ${open.length ? groups.map(([c, l]) => `<section class="panel shop"><h2>${esc(c)}</h2><ul>${l.map(item).join("")}</ul></section>`).join("")
        : `<div class="panel empty"><b>${done.length ? "Усе куплено 🎉" : "Список порожній"}</b>Додайте позиції вище${DEMO ? "" : " або напишіть боту в Telegram"}.</div>`}
      ${done.length ? `<section class="panel shop"><h2 class="row"><span>Куплено (${done.length})</span><button class="link" data-act="shopClear">прибрати</button></h2><ul>${done.map(item).join("")}</ul></section>` : ""}`;
  }

  // ───── Витрати сімʼї (Monobank) ─────
  const UAH = (x, d = 0) => `${num(x, d)} ₴`;
  const CAT_ICON = { "Продукти": "🛒", "Кафе й ресторани": "🍽", "Транспорт і авто": "🚗", "Здоровʼя й аптека": "💊", "Комуналка й звʼязок": "💡", "Діти": "🧸", "Одяг і взуття": "👕", "Дім і техніка": "🏠", "Розваги й підписки": "🎬", "Подорожі": "✈️", "Краса": "💅", "Тварини": "🐾", "Готівка": "💵", "Перекази": "↔️", "Надходження": "⬇️", "Інше": "•" };
  async function renderSpend() {
    shell(`${shopHead()}<div id="mbox2"><div class="empty">Завантаження…</div></div>`);
    drawSpend(await callMoney("money", { month: st.spendMonth }).then((j) => { if (!j.ok) { toast(j.error); throw new Error(j.error); } return j; }));
  }
  const MTABS = [["over", "Огляд"], ["budget", "Бюджет"], ["plans", "Платежі"], ["goals", "Цілі"], ["ops", "Операції"]];
  const pctCls = (p) => (p >= 100 ? "over" : p >= 80 ? "warn" : "");
  const bar = (v, max, cls = "") => `<div class="pbar ${cls}"><i style="width:${Math.min(100, max > 0 ? (v / max) * 100 : 0)}%"></i></div>`;
  const ddmm = (d) => `${d.slice(8, 10)}.${d.slice(5, 7)}`;
  const dueTxt = (p) => {
    if (p.paid) return '<span class="tag ok">оплачено</span>';
    const n = Math.round((Date.parse(p.due) - Date.parse(today())) / 86400000);
    return n < 0 ? `<span class="tag now">прострочено</span>` : n === 0 ? '<span class="tag now">сьогодні</span>' : n <= 3 ? `<span class="tag warn">через ${n} дн.</span>` : `<span class="tag">${ddmm(p.due)}</span>`;
  };
  function drawSpend(j) {
    st.spend = j;
    const box = $("#mbox2"); if (!box) return;
    const D0 = D(j.month + "-01"), P = j.planner, curM = j.month === today().slice(0, 7);
    $("#shop-sub").textContent = `${MONN[D0.getMonth()]} ${D0.getFullYear()}`;
    st.mTab ??= "over";
    const tabs = `<div class="seg mseg" role="group" aria-label="Гроші">${MTABS.map(([k, l]) => `<button data-act="mTab" data-v="${k}" aria-pressed="${st.mTab === k}">${l}</button>`).join("")}</div>`;
    const monthNav = `<div class="nav-date"><button class="icon" data-act="spShift" data-n="-1" aria-label="Попередній місяць">${ICON.left}</button><div class="l">${MONN[D0.getMonth()]} ${D0.getFullYear()}</div><button class="icon" data-act="spShift" data-n="1" aria-label="Наступний місяць">${ICON.right}</button></div>`;
    const views = { over: overView, budget: budgetView, plans: plansView, goals: goalsView, ops: opsView };
    box.innerHTML = tabs + (st.mTab === "goals" ? "" : monthNav) + views[st.mTab](j, P, curM);
    box.querySelectorAll("[data-mono-acc]").forEach((el) => el.addEventListener("change", async () => {
      const lid = +el.dataset.link, inc = [...box.querySelectorAll(`[data-mono-acc][data-link="${lid}"]`)].filter((x) => x.checked).map((x) => x.dataset.monoAcc);
      const r = await callMoney("mono_update", { link_id: lid, include: inc, month: st.spendMonth }); if (!r.ok) return toast(r.error); drawSpend(r);
    }));
    box.querySelectorAll("[data-mono-share]").forEach((el) => el.addEventListener("change", async () => {
      const r = await callMoney("mono_update", { link_id: +el.dataset.monoShare, share: el.value, month: st.spendMonth }); if (!r.ok) return toast(r.error); drawSpend(r); toast("Збережено");
    }));
  }
  // ── Графік: план (бюджет або минулий місяць) / факт наростаючим підсумком / прогноз до кінця місяця
  function spendChart(j, P, curM) {
    const [y, m] = j.month.split("-").map(Number), N = new Date(y, m, 0).getDate();
    const isPast = j.month < today().slice(0, 7), isFut = j.month > today().slice(0, 7);
    const dEnd = isFut ? 0 : isPast ? N : new Date().getDate();
    const cum = [0]; for (let d = 1; d <= dEnd; d++) cum[d] = cum[d - 1] + (j.by_day[`${j.month}-${String(d).padStart(2, "0")}`] || 0);
    const fact = cum[dEnd] || 0, plan = P.budget_total || j.prev_total || 0, planSrc = P.budget_total ? "бюджет" : "як минулого місяця";
    const fc = curM && dEnd >= 3 ? Math.round(fact + (fact / dEnd) * (N - dEnd)) : null;
    if (!plan && !fact) return "";
    const W = 340, H = 170, L = 8, R = 8, T = 14, B = 22, maxY = Math.max(plan, fc || 0, fact, 1) * 1.08;
    const X = (d) => L + (d / N) * (W - L - R), Y = (v) => T + (1 - v / maxY) * (H - T - B);
    const pts = cum.map((v, d) => `${X(d).toFixed(1)},${Y(v).toFixed(1)}`).join(" ");
    const area = dEnd ? `M${X(0)},${Y(0)} L${pts.replace(/ /g, " L")} L${X(dEnd)},${Y(0)} Z` : "";
    const over = fc != null ? fc > plan : fact > plan;
    const ticks = [1, 10, 20, N].map((d) => `<text x="${X(d)}" y="${H - 6}" text-anchor="${d === N ? "end" : d === 1 ? "start" : "middle"}">${d}</text>`).join("");
    const pctToday = plan ? Math.round((fact / ((plan * dEnd) / N || 1)) * 100) : null;
    return `<section class="panel"><h2 class="row"><span>📈 План / факт</span><em>${planSrc}</em></h2>
      <svg class="pfchart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Витрати наростаючим підсумком: факт ${num(fact)} ₴, план ${num(plan)} ₴${fc != null ? `, прогноз ${num(fc)} ₴` : ""}">
        <line class="base" x1="${L}" x2="${W - R}" y1="${Y(0)}" y2="${Y(0)}"/>
        ${plan ? `<line class="plan" x1="${X(0)}" y1="${Y(0)}" x2="${X(N)}" y2="${Y(plan)}"/><text class="lbl" x="${X(N) - 2}" y="${Y(plan) + ((fc ?? fact) > plan ? 14 : -5)}" text-anchor="end">план ${num(plan)}</text>` : ""}
        ${area ? `<path class="area" d="${area}"/><polyline class="fact" points="${pts}"/>` : ""}
        ${fc != null ? `<line class="fc ${over ? "over" : ""}" x1="${X(dEnd)}" y1="${Y(fact)}" x2="${X(N)}" y2="${Y(fc)}"/><circle class="fcdot ${over ? "over" : ""}" cx="${X(N)}" cy="${Y(fc)}" r="3.5"/>` : ""}
        ${dEnd && dEnd < N ? `<line class="today" x1="${X(dEnd)}" x2="${X(dEnd)}" y1="${T - 4}" y2="${Y(0)}"/><circle class="fdot" cx="${X(dEnd)}" cy="${Y(fact)}" r="4"/>` : ""}
        <g class="ax">${ticks}</g>
      </svg>
      <div class="legend"><span><i class="lg-fact"></i>факт ${UAH(fact)}</span>${plan ? `<span><i class="lg-plan"></i>план ${UAH(plan)}</span>` : ""}${fc != null ? `<span><i class="lg-fc ${over ? "over" : ""}"></i>прогноз ${UAH(fc)}</span>` : ""}</div>
      <p class="note" style="margin:8px 0 0">${fc != null && plan
        ? (over ? `За поточного темпу до кінця місяця вийде <b class="over">${UAH(fc)}</b> — на ${UAH(fc - plan)} більше за план. Щоб вкластися, далі не більше ${UAH(Math.max(0, (plan - fact) / Math.max(1, N - dEnd)))} на день.`
                : `За поточного темпу вийде ${UAH(fc)} — у межах плану, запас ${UAH(plan - fc)}. Можна витрачати до ${UAH((plan - fact) / Math.max(1, N - dEnd))} на день.`)
        : isPast && plan ? (fact > plan ? `Перевищення плану на ${UAH(fact - plan)}.` : `Вклалися в план, зекономлено ${UAH(plan - fact)}.`)
        : curM && plan ? `Сьогодні витрачено ${pctToday}% від того, що за планом мало б бути на ${dEnd}-те число.` : ""}</p>
    </section>`;
  }
  // ── Огляд: рахунки, прогноз, бюджет місяця, найближчі платежі, цілі
  function overView(j, P, curM) {
    const F = P.forecast, budSpent = P.budgets.reduce((s, b) => s + b.spent, 0);
    const up = P.plans.filter((p) => !p.paid).sort((a, b) => a.due.localeCompare(b.due)).slice(0, 4);
    const base = j.prev_same ?? j.prev_total, diff = base > 0 ? Math.round(((j.total - base) / base) * 100) : null;
    return `
      <section class="panel"><h2 class="row"><span>💰 На рахунках</span><button class="link" data-act="accNew">+ готівка</button></h2>
        <div class="money"><b>${num(P.total)}</b><span>₴</span></div>
        ${P.accounts.length ? `<ul class="acc">${P.accounts.map((a) => `<li${a.kind === "cash" ? ` class="tap" data-act="accOpen" data-id="${a.cid}"` : ""}><span>${a.kind === "cash" ? "💵" : "💳"} ${esc(a.name)}<small>${esc(a.owner)}${a.kind === "mono" && a.balance == null ? " · залишок оновиться за кілька хвилин" : ""}</small></span><b>${a.balance == null ? "—" : UAH(a.balance)}</b></li>`).join("")}</ul>` : '<p class="note" style="margin:6px 0 0">Підключіть Monobank (вкладка «Операції») або додайте готівку.</p>'}
      </section>
      ${F ? `<section class="panel"><h2>🔮 Прогноз на кінець місяця</h2>
        <div class="money"><b class="${F.end < 0 ? "neg" : ""}">${num(F.end)}</b><span>₴</span></div>
        <ul class="flist"><li><span>Зараз на рахунках</span><b>${UAH(F.balance)}</b></li>
          ${F.income ? `<li><span>Очікувані надходження</span><b class="inc">+${UAH(F.income)}</b></li>` : ""}
          ${F.planned ? `<li><span>Регулярні платежі</span><b>−${UAH(F.planned)}</b></li>` : ""}
          ${F.budget_left ? `<li><span>Ще в межах бюджету</span><b>−${UAH(F.budget_left)}</b></li>` : ""}</ul>
        ${!P.budgets.length && !P.plans.length ? '<p class="note" style="margin:8px 0 0">Додайте бюджет і регулярні платежі — прогноз стане точним.</p>' : ""}</section>` : ""}
      <section class="panel tap" data-act="mTab" data-v="budget"><h2 class="row"><span>📊 Витрати за місяць</span><em>${diff != null ? `${diff > 0 ? "+" : ""}${diff}% до минулого` : ""}</em></h2>
        <div class="money"><b>${num(j.total)}</b><span>₴${P.budget_total ? ` із ${num(P.budget_total)} бюджету` : ""}</span></div>
        ${P.budget_total ? bar(budSpent, P.budget_total, pctCls((budSpent / P.budget_total) * 100)) : ""}
        ${j.income ? `<p class="note" style="margin:8px 0 0">Надходження: ${UAH(j.income)}</p>` : ""}</section>
      ${spendChart(j, P, curM)}
      <section class="panel"><h2 class="row"><span>🔔 Найближчі платежі</span><button class="link" data-act="mTab" data-v="plans">усі</button></h2>
        ${up.length ? `<ul class="plist2">${up.map((p) => `<li class="tap" data-act="planOpen" data-id="${p.id}"><span>${esc(p.title)}<small>${dueTxt(p)}</small></span><b class="${p.kind === "income" ? "inc" : ""}">${p.kind === "income" ? "+" : ""}${UAH(p.amount)}</b></li>`).join("")}</ul>` : `<p class="note" style="margin:0">${P.plans.length ? "Усе сплачено 🎉" : "Додайте комуналку, інтернет, підписки — нагадаю в Telegram."}</p>`}</section>
      ${P.goals.length ? `<section class="panel tap" data-act="mTab" data-v="goals"><h2>🎯 Цілі</h2>${P.goals.slice(0, 3).map((g) => `<div class="gmini"><span>${esc(g.title)}<small>${UAH(g.saved)} із ${UAH(g.target)}</small></span>${bar(g.saved, g.target, g.done ? "done" : "")}</div>`).join("")}</section>` : ""}`;
  }
  // ── Бюджет: ліміти за категоріями
  function budgetView(j, P) {
    const bud = new Map(P.budgets.map((b) => [b.category, b]));
    const extra = j.by_category.filter((c) => !bud.has(c.k));
    const tot = P.budgets.reduce((s, b) => s + b.limit, 0), sp = P.budgets.reduce((s, b) => s + b.spent, 0);
    return `
      ${spendChart(j, P, j.month === today().slice(0, 7))}
      ${tot ? `<section class="panel"><div class="money"><b>${num(sp)}</b><span>₴ із ${num(tot)}</span></div>${bar(sp, tot, pctCls((sp / tot) * 100))}<p class="note" style="margin:8px 0 0">Лишилось ${UAH(Math.max(0, tot - sp))}. Попередження в сімейну групу — при 80% і перевищенні.</p></section>` : ""}
      <section class="panel"><h2 class="row"><span>Ліміти на місяць</span><button class="link" data-act="budNew">+ ліміт</button></h2>
        ${P.budgets.length ? `<ul class="blist">${P.budgets.map((b) => { const pc = b.limit ? (b.spent / b.limit) * 100 : 0; return `<li class="tap" data-act="budOpen" data-c="${esc(b.category)}"><div class="row"><span>${CAT_ICON[b.category] || "•"} ${esc(b.category)}</span><b class="${pctCls(pc)}">${num(b.spent)} / ${num(b.limit)} ₴</b></div>${bar(b.spent, b.limit, pctCls(pc))}<small>${b.spent > b.limit ? `перевищено на ${UAH(b.spent - b.limit)}` : `лишилось ${UAH(b.limit - b.spent)}`}</small></li>`; }).join("")}</ul>`
          : '<p class="note" style="margin:0">Задайте, скільки сімʼя готова витрачати на місяць за категоріями: продукти, кафе, транспорт…</p>'}
      </section>
      ${extra.length ? `<section class="panel"><h2>Без ліміту</h2><ul class="blist">${extra.map((c) => `<li class="tap" data-act="budOpen" data-c="${esc(c.k)}"><div class="row"><span>${CAT_ICON[c.k] || "•"} ${esc(c.k)}</span><b>${UAH(c.v)}</b></div><small>натисніть, щоб задати ліміт</small></li>`).join("")}</ul></section>` : ""}`;
  }
  // ── Регулярні платежі
  function plansView(j, P) {
    const exp = P.plans.filter((p) => p.kind === "expense"), inc = P.plans.filter((p) => p.kind === "income");
    const row = (p) => `<li class="tap" data-act="planOpen" data-id="${p.id}"><span>${esc(p.title)}<small>${dueTxt(p)}${p.every === "year" ? " · щороку" : ""}${p.auto ? " · знайдено у виписці" : ""}</small></span><b class="${p.kind === "income" ? "inc" : ""}">${p.kind === "income" ? "+" : ""}${UAH(p.amount)}</b></li>`;
    const unpaid = exp.filter((p) => !p.paid).reduce((s, p) => s + p.amount, 0);
    return `
      <section class="panel"><h2 class="row"><span>Платежі цього місяця</span><button class="link" data-act="planNew">+ платіж</button></h2>
        ${exp.length ? `<p class="note" style="margin:0 0 8px">Ще сплатити: <b>${UAH(unpaid)}</b> із ${UAH(exp.reduce((s, p) => s + p.amount, 0))}</p><ul class="plist2">${exp.map(row).join("")}</ul>` : '<p class="note" style="margin:0">Комуналка, інтернет, телефон, підписки, кредит. Я нагадаю в Telegram за кілька днів і сам позначу оплаченим, коли побачу платіж у виписці.</p>'}
      </section>
      <section class="panel"><h2 class="row"><span>Надходження</span><button class="link" data-act="planNew" data-k="income">+ дохід</button></h2>
        ${inc.length ? `<ul class="plist2">${inc.map(row).join("")}</ul>` : '<p class="note" style="margin:0">Зарплата, аванс, оренда — щоб прогноз враховував, що гроші ще прийдуть.</p>'}
      </section>`;
  }
  // ── Цілі
  function goalsView(j, P) {
    return `<section class="panel"><h2 class="row"><span>Цілі накопичень</span><button class="link" data-act="goalNew">+ ціль</button></h2>
      ${P.goals.length ? P.goals.map((g) => `<div class="goal tap" data-act="goalOpen" data-id="${g.id}"><div class="row"><b>${g.done ? "✅ " : ""}${esc(g.title)}</b><span>${Math.round((g.saved / g.target) * 100)}%</span></div>${bar(g.saved, g.target, g.done ? "done" : "")}
        <small>${UAH(g.saved)} із ${UAH(g.target)}${g.deadline ? ` · до ${ddmm(g.deadline)}.${g.deadline.slice(0, 4)}` : ""}${g.monthly ? ` · відкладати ≈ ${UAH(g.monthly)}/міс` : ""}${g.jar ? ` · банка «${esc(g.jar)}»` : ""}</small></div>`).join("")
        : '<p class="note" style="margin:0">Відпустка, ремонт, подушка безпеки. Можна привʼязати до «банки» Monobank — прогрес оновлюватиметься сам.</p>'}
    </section>`;
  }
  // ── Операції: категорії, список, підключення банку
  function opsView(j) {
    const anyLink = j.family.some((f) => f.connected), myLinks = j.links;
    const maxCat = Math.max(1, ...j.by_category.map((c) => c.v));
    const list = j.txns.filter((t) => !st.spendCat || t.category === st.spendCat);
    const byDay = {}; for (const t of list) { const d = iso(new Date(Date.parse(t.ts))); (byDay[d] ??= []).push(t); }
    const connect = `<section class="panel"><h2>Підключити мій Monobank</h2>
        <ol class="steps"><li>Відкрийте <a href="https://api.monobank.ua/" target="_blank" rel="noopener">api.monobank.ua</a> і відскануйте QR-код у застосунку Monobank.</li><li>Скопіюйте токен, який покаже сторінка.</li><li>Вставте його сюди.</li></ol>
        <label class="field"><span>Токен Monobank</span><input id="mono-tok" autocomplete="off" placeholder="uXXXXXXXX…"></label>
        <button class="btn lamp" data-act="monoConnect">Підключити</button>
        <p class="note">Токен дає лише перегляд виписки й залишків — платити ним не можна. Зберігається зашифровано на сервері.</p></section>`;
    const myBank = myLinks.map((l) => `<section class="panel"><h2 class="row"><span>Мій Monobank${l.client_name ? ` · ${esc(l.client_name)}` : ""}</span><button class="link danger" data-act="monoOff" data-id="${l.id}">відключити</button></h2>
        ${l.pending ? `<p class="note" style="margin:0 0 10px">⏳ Підтягую історію: ще ≈ ${l.pending} хв (банк дозволяє 1 запит на хвилину)</p>` : `<p class="note" style="margin:0 0 10px">${l.hook_ok ? "🟢 Нові покупки зʼявляються одразу" : "Оновлюється раз на 6 годин"}${l.last_sync ? ` · синхронізовано ${agoT(l.last_sync)}` : ""}</p>`}
        ${l.last_error ? `<p class="err" style="margin:0 0 10px">${esc(l.last_error)}</p>` : ""}
        ${l.accounts.map((a) => `<label class="check"><input type="checkbox" data-mono-acc="${esc(a.id)}" data-link="${l.id}" ${a.include ? "checked" : ""} ${a.currency !== 980 ? "disabled" : ""}> ${esc(a.label)}${a.currency !== 980 ? ' <small class="muted">(валюта — не враховується)</small>' : ""}</label>`).join("")}
        <label class="field" style="margin-top:6px"><span>Що бачить сімʼя</span><select data-mono-share="${l.id}"><option value="full" ${l.share === "full" ? "selected" : ""}>Усі мої операції</option><option value="totals" ${l.share === "totals" ? "selected" : ""}>Лише суми по категоріях</option></select></label>
      </section>`).join("");
    return `${anyLink || j.total ? `
      <section class="panel"><h2 class="row"><span>Категорії</span>${st.spendCat ? '<button class="link" data-act="spCat" data-c="">усі</button>' : ""}</h2>
        ${j.by_member.length > 1 ? `<div class="mbar">${j.by_member.map((m, i) => `<i class="c${i % 4}" style="flex:${m.v}" title="${esc(m.k)}"></i>`).join("")}</div><div class="legend" style="margin-bottom:10px">${j.by_member.map((m, i) => `<span><i class="c${i % 4}"></i>${esc(m.k)} · ${UAH(m.v)}</span>`).join("")}</div>` : ""}
        ${j.by_category.length ? `<ul class="cats">${j.by_category.map((c) => `<li><button data-act="spCat" data-c="${esc(c.k)}" aria-pressed="${st.spendCat === c.k}"><span class="ci">${CAT_ICON[c.k] || "•"}</span><span class="cn">${esc(c.k)}<i style="width:${(c.v / maxCat) * 100}%"></i></span><b>${UAH(c.v)}</b></button></li>`).join("")}</ul>` : '<p class="note" style="margin:0">У цьому місяці витрат ще немає.</p>'}
      </section>` : ""}
      <section class="panel"><h2 class="row"><span>${st.spendCat ? esc(st.spendCat) : "Операції"}</span><button class="link" data-act="cashAdd">+ операція</button></h2>
        ${Object.keys(byDay).length ? Object.entries(byDay).map(([d, ts]) => `<div class="txday">${dayLabel(d)}</div>${ts.map((t) => `<button class="tx ${t.hidden ? "hid" : ""}" data-act="txOpen" data-id="${esc(t.id)}"><span class="av">${esc((t.member || "?").slice(0, 1))}</span><span class="td">${esc(t.description || t.category)}<small>${CAT_ICON[t.category] || ""} ${esc(t.category)}${t.hidden ? " · не враховано" : ""}${t.comment ? ` · ${esc(t.comment)}` : ""}</small></span><b class="${t.amount > 0 ? "inc" : ""}">${t.amount > 0 ? "+" : "−"}${num(Math.abs(t.amount), 2)}${t.currency === 980 ? "" : " вал."}</b></button>`).join("")}`).join("")
          : '<p class="note" style="margin:0">Операцій немає.</p>'}
      </section>
      ${myBank || connect}
      ${j.family.length > 1 ? `<p class="credit">Підключено: ${j.family.map((f) => `${esc(f.name)} ${f.connected ? "✓" : "—"}`).join(" · ")}</p>` : ""}`;
  }
  function txSheet(t) {
    const cats = st.spend.categories;
    const s = sheet(`<h2>${esc(t.description || "Операція")}<button class="icon" data-close aria-label="Закрити">${ICON.x}</button></h2>
      <p class="muted" style="margin:-6px 0 12px">${esc(t.member)} · ${dayLabel(iso(new Date(Date.parse(t.ts))))}, ${hm(Date.parse(t.ts))} · <b>${t.amount > 0 ? "+" : "−"}${num(Math.abs(t.amount), 2)} ₴</b></p>
      ${t.mine ? `<label class="field"><span>Категорія</span><select id="tx-cat">${cats.map((c) => `<option ${c === t.category ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
      <label class="check"><input type="checkbox" id="tx-hid" ${t.hidden ? "checked" : ""}> Не враховувати у витратах</label>
      <div class="foot">${t.manual ? '<button class="btn light danger" id="tx-del">Видалити</button>' : ""}<button class="btn lamp" id="tx-save">Зберегти</button></div>`
      : '<p class="note">Змінювати категорію може лише власник картки.</p>'}`);
    const save = $("#tx-save", s);
    if (save) save.addEventListener("click", async () => { const r = await callMoney("txn_update", { id: t.id, category: $("#tx-cat", s).value, hidden: $("#tx-hid", s).checked, month: st.spendMonth }); if (!r.ok) return toast(r.error); closeSheet(); drawSpend(r); });
    const del = $("#tx-del", s);
    if (del) del.addEventListener("click", async () => { const r = await callMoney("txn_update", { id: t.id, delete: true, month: st.spendMonth }); if (!r.ok) return toast(r.error); closeSheet(); drawSpend(r); });
  }
  const spendCats = () => st.spend.categories.filter((c) => c !== "Перекази" && c !== "Надходження");
  const mDone = (r) => { if (!r.ok) { toast(r.error); return false; } closeSheet(); drawSpend(r); return true; };
  function cashSheet() {
    const cash = st.spend.planner.accounts.filter((a) => a.kind === "cash");
    const s = sheet(`<h2>Нова операція<button class="icon" data-close aria-label="Закрити">${ICON.x}</button></h2>
      <div class="seg" style="margin-bottom:12px"><button type="button" data-k="expense" aria-pressed="true">Витрата</button><button type="button" data-k="income" aria-pressed="false">Надходження</button></div>
      <div class="row2"><label class="field"><span>Сума, ₴</span><input id="c-am" inputmode="decimal" placeholder="0"></label><label class="field"><span>Дата</span><input id="c-day" type="date" value="${today()}"></label></div>
      <label class="field" id="c-catf"><span>Категорія</span><select id="c-cat">${spendCats().map((c) => `<option>${esc(c)}</option>`).join("")}</select></label>
      ${cash.length ? `<label class="field"><span>Рахунок</span><select id="c-acc"><option value="">— не з рахунку —</option>${cash.map((a) => `<option value="${a.cid}">${esc(a.name)} (${UAH(a.balance)})</option>`).join("")}</select></label>` : ""}
      <label class="field"><span>Опис</span><input id="c-note" placeholder="Напр.: ринок"></label>
      <div class="foot"><button class="btn lamp" id="c-save">Додати</button></div>`);
    let kind = "expense";
    s.querySelectorAll("[data-k]").forEach((b) => b.addEventListener("click", () => { kind = b.dataset.k; s.querySelectorAll("[data-k]").forEach((x) => x.setAttribute("aria-pressed", x === b)); $("#c-catf", s).hidden = kind === "income"; }));
    setTimeout(() => $("#c-am", s)?.focus(), 50);
    $("#c-save", s).addEventListener("click", async () => {
      const r = await callMoney("txn_add", { kind, amount: $("#c-am", s).value, category: $("#c-cat", s).value, note: $("#c-note", s).value, day: $("#c-day", s).value, account_id: $("#c-acc", s)?.value || undefined, month: st.spendMonth });
      if (mDone(r)) st.spendMonth = r.month;
    });
  }
  function budSheet(cat) {
    const b = st.spend.planner.budgets.find((x) => x.category === cat);
    const s = sheet(`<h2>${b ? "Ліміт" : "Новий ліміт"}<button class="icon" data-close aria-label="Закрити">${ICON.x}</button></h2>
      <label class="field"><span>Категорія</span><select id="b-cat" ${b ? "disabled" : ""}>${spendCats().map((c) => `<option ${c === cat ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
      <label class="field"><span>Ліміт на місяць, ₴</span><input id="b-am" inputmode="decimal" value="${b ? b.limit : ""}" placeholder="Напр.: 15000"></label>
      ${b ? `<p class="note">Цього місяця: ${UAH(b.spent)}</p>` : ""}
      <div class="foot">${b ? '<button class="btn light danger" id="b-del">Прибрати ліміт</button>' : ""}<button class="btn lamp" id="b-save">Зберегти</button></div>`);
    setTimeout(() => $("#b-am", s)?.focus(), 50);
    $("#b-save", s).addEventListener("click", async () => mDone(await callMoney("budget_set", { category: $("#b-cat", s).value, amount: $("#b-am", s).value, month: st.spendMonth })));
    $("#b-del", s)?.addEventListener("click", async () => mDone(await callMoney("budget_set", { category: cat, amount: 0, month: st.spendMonth })));
  }
  function planSheet(p, kind0) {
    const e = p || { kind: kind0 || "expense", day: new Date().getDate(), every: "month", remind_days: 2 };
    const s = sheet(`<h2>${p ? esc(p.title) : e.kind === "income" ? "Регулярний дохід" : "Регулярний платіж"}<button class="icon" data-close aria-label="Закрити">${ICON.x}</button></h2>
      ${p ? `<p class="muted" style="margin:-6px 0 12px">${dueTxt(p)}${p.auto ? " · знайдено у виписці" : ""}</p>` : ""}
      <label class="field"><span>Назва</span><input id="p-t" value="${esc(e.title || "")}" placeholder="${e.kind === "income" ? "Зарплата" : "Інтернет, комуналка, Netflix…"}"></label>
      <div class="row2"><label class="field"><span>Сума, ₴</span><input id="p-am" inputmode="decimal" value="${e.amount || ""}"></label><label class="field"><span>День місяця</span><input id="p-day" type="number" min="1" max="31" value="${e.day}"></label></div>
      <div class="row2"><label class="field"><span>Повтор</span><select id="p-ev"><option value="month" ${e.every === "month" ? "selected" : ""}>Щомісяця</option><option value="year" ${e.every === "year" ? "selected" : ""}>Щороку</option></select></label>
        <label class="field" id="p-mf" ${e.every === "year" ? "" : "hidden"}><span>Місяць</span><select id="p-mo">${MONN.map((m, i) => `<option value="${i + 1}" ${e.month === i + 1 ? "selected" : ""}>${m}</option>`).join("")}</select></label></div>
      ${e.kind === "expense" ? `<label class="field"><span>Категорія</span><select id="p-cat"><option value="">—</option>${spendCats().map((c) => `<option ${c === e.category ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
        <label class="field"><span>Нагадати в Telegram</span><select id="p-rem">${[[0, "у день платежу"], [1, "за 1 день"], [2, "за 2 дні"], [3, "за 3 дні"], [5, "за 5 днів"], [7, "за тиждень"]].map(([v, l]) => `<option value="${v}" ${e.remind_days === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>` : ""}
      <label class="field"><span>Слово з опису у виписці <small class="muted">(необовʼязково)</small></span><input id="p-match" value="${esc(e.match || "")}" placeholder="${e.kind === "income" ? "Напр.: назва роботодавця" : "Напр.: Київстар"}"></label>
      <div class="foot">${p ? `<button class="btn light" id="p-paid">${p.paid ? "Не оплачено" : "Оплачено"}</button><button class="btn light danger" id="p-del">Видалити</button>` : ""}<button class="btn lamp" id="p-save">Зберегти</button></div>`);
    $("#p-ev", s).addEventListener("change", (ev) => { $("#p-mf", s).hidden = ev.target.value !== "year"; });
    $("#p-save", s).addEventListener("click", async () => mDone(await callMoney("plan_save", { plan: { id: p?.id, kind: e.kind, title: $("#p-t", s).value, amount: $("#p-am", s).value, day: $("#p-day", s).value, every: $("#p-ev", s).value, month: $("#p-mo", s).value, category: $("#p-cat", s)?.value, remind_days: $("#p-rem", s)?.value, match: $("#p-match", s).value }, month: st.spendMonth })));
    $("#p-paid", s)?.addEventListener("click", async () => mDone(await callMoney("plan_paid", { id: p.id, paid: !p.paid, month: st.spendMonth })));
    $("#p-del", s)?.addEventListener("click", async (ev) => { if (ev.target.dataset.sure !== "1") { ev.target.dataset.sure = "1"; ev.target.textContent = "Точно?"; return; } mDone(await callMoney("plan_delete", { id: p.id, month: st.spendMonth })); });
  }
  function goalSheet(g) {
    const jars = st.spend.planner.jars;
    const s = sheet(`<h2>${g ? esc(g.title) : "Нова ціль"}<button class="icon" data-close aria-label="Закрити">${ICON.x}</button></h2>
      ${g && !g.jar_id ? `<div class="row2" style="align-items:end"><label class="field"><span>Поповнити / зняти, ₴</span><input id="g-add" inputmode="decimal" placeholder="1000 або -500"></label><button class="btn lamp" id="g-addb" style="margin-bottom:12px">Додати</button></div>` : ""}
      <label class="field"><span>Назва</span><input id="g-t" value="${esc(g?.title || "")}" placeholder="Відпустка, ремонт, подушка безпеки"></label>
      <div class="row2"><label class="field"><span>Сума цілі, ₴</span><input id="g-tg" inputmode="decimal" value="${g?.target || ""}"></label><label class="field"><span>До дати</span><input id="g-dl" type="date" value="${g?.deadline || ""}"></label></div>
      ${jars.length ? `<label class="field"><span>Банка Monobank</span><select id="g-jar"><option value="">— вести вручну —</option>${jars.map((x) => `<option value="${esc(x.id)}" ${g?.jar_id === x.id ? "selected" : ""}>${esc(x.title)} · ${UAH(x.balance)} (${esc(x.owner)})</option>`).join("")}</select></label>` : ""}
      ${g ? "" : `<label class="field"><span>Вже відкладено, ₴</span><input id="g-sv" inputmode="decimal" placeholder="0"></label>`}
      <div class="foot">${g ? '<button class="btn light danger" id="g-del">Видалити</button>' : ""}<button class="btn lamp" id="g-save">Зберегти</button></div>`);
    $("#g-save", s).addEventListener("click", async () => mDone(await callMoney("goal_save", { goal: { id: g?.id, title: $("#g-t", s).value, target: $("#g-tg", s).value, deadline: $("#g-dl", s).value, jar_id: $("#g-jar", s)?.value || null, saved: $("#g-sv", s)?.value }, month: st.spendMonth })));
    $("#g-addb", s)?.addEventListener("click", async () => mDone(await callMoney("goal_add", { id: g.id, amount: $("#g-add", s).value, month: st.spendMonth })));
    $("#g-del", s)?.addEventListener("click", async (ev) => { if (ev.target.dataset.sure !== "1") { ev.target.dataset.sure = "1"; ev.target.textContent = "Точно?"; return; } mDone(await callMoney("goal_delete", { id: g.id, month: st.spendMonth })); });
  }
  function accSheet(a) {
    const s = sheet(`<h2>${a ? esc(a.name) : "Рахунок готівки"}<button class="icon" data-close aria-label="Закрити">${ICON.x}</button></h2>
      <label class="field"><span>Назва</span><input id="a-n" value="${esc(a?.name || "")}" placeholder="Готівка вдома, гаманець…"></label>
      <label class="field"><span>${a ? `Фактичний залишок зараз, ₴ <small class="muted">(зараз ${UAH(a.balance)})</small>` : "Скільки зараз, ₴"}</span><input id="a-o" inputmode="decimal" placeholder="${a ? "залиште порожнім, щоб не міняти" : "0"}"></label>
      <p class="note">Витрати й надходження з цього рахунку додавайте через «+ операція» — залишок рахуватиметься сам.</p>
      <div class="foot">${a ? '<button class="btn light danger" id="a-del">Видалити</button>' : ""}<button class="btn lamp" id="a-save">Зберегти</button></div>`);
    $("#a-save", s).addEventListener("click", async () => mDone(await callMoney("account_save", { id: a?.cid, name: $("#a-n", s).value, opening: $("#a-o", s).value, month: st.spendMonth })));
    $("#a-del", s)?.addEventListener("click", async () => mDone(await callMoney("account_delete", { id: a.cid, month: st.spendMonth })));
  }

  // ───── Події ─────
  async function renderEvents() {
    shell(`<div class="head">${st.tab === "more" ? back("goMenu") : ""}<h1 class="grow">Події</h1><button class="ghost" data-act="newEvent">+ Подія</button></div><div id="ebox"><div class="empty">Завантаження…</div></div>`);
    drawEvents(await must("events_list"));
  }
  function drawEvents(j) {
    st.ev = j;
    const box = $("#ebox"); if (!box) return;
    const names = Object.fromEntries(j.members.map((m) => [m.id, m.name]));
    const t = j.today, to = addDays(t, 60);
    const occ = j.events.flatMap((e) => occDays(e, t, to).map((d) => ({ e, d }))).sort((a, b) => (a.d + (a.e.tm || "00:00")).localeCompare(b.d + (b.e.tm || "00:00")));
    const nowHm = hm(Date.now());
    // щотижневі — лише на 2 тижні вперед, щоб не засмічувати список
    const visible = occ.filter((o) => !(o.e.rep === "weekly" && o.d > addDays(t, 13)) && !(o.d === t && o.e.tm && o.e.tm < nowHm && o.e.rep !== "none"));
    const byDay = {}; for (const o of visible) (byDay[o.d] ??= []).push(o);
    const pw = j.power;
    box.innerHTML = `
      <section class="panel power">
        <h2>${ICON.plug} Коли дадуть світло</h2>
        <p class="note" style="margin:0 0 10px">${j.light_off ? "Зараз світла немає — нагадаю в групі, щойно воно зʼявиться." : "Нагадаю в групі, коли світло дадуть після наступного відключення."}</p>
        ${pw.length ? `<ul class="plist">${pw.map((p) => `<li class="${p.notified_at ? "fired" : ""}"><span>${esc(p.title)}<small>${p.notified_at ? `нагадано о ${hm(Date.parse(p.notified_at))}` : esc(p.created_name)}</small></span><button class="del" data-act="powerDone" data-id="${p.id}" aria-label="Готово: ${esc(p.title)}">${p.notified_at ? ICON.check : ICON.x}</button></li>`).join("")}</ul>` : ""}
        <form class="addbar small" id="pw-form" autocomplete="off"><input id="pw-in" placeholder="Напр.: увімкнути пральку" aria-label="Справа, коли дадуть світло"><button class="addbtn" aria-label="Додати">${ICON.plus}</button></form>
      </section>
      ${Object.keys(byDay).length ? Object.entries(byDay).map(([d, l]) => `<section class="eday"><h3>${dayLabel(d)}${d !== t && d !== addDays(t, 1) ? "" : `<small>${WDL[D(d).getDay()]}, ${dLong(d)}</small>`}</h3>
        ${l.map(({ e }) => `<button class="ecard" data-act="openEvent" data-id="${e.id}">
          <span class="tm">${e.tm || "весь<br>день"}</span>
          <span class="bd"><b>${esc(e.title)}</b><small>${[e.who ? esc(names[e.who] || "") : "усі", REP[e.rep] ? `${REP[e.rep]}` : "", e.notes ? esc(e.notes) : ""].filter(Boolean).join(" · ")}</small></span>
          ${e.rep !== "none" ? `<span class="ri" aria-label="${REP[e.rep]}">${ICON.rep}</span>` : ""}
        </button>`).join("")}</section>`).join("")
        : `<div class="panel empty"><b>Подій немає</b>Додайте візит до лікаря, поїздку чи день народження — нагадування прийде в Telegram.</div>`}`;
    $("#pw-form").addEventListener("submit", async (e) => {
      e.preventDefault(); const v = $("#pw-in").value.trim(); if (!v) return;
      const r = await call("power_add", { title: v }); if (!r.ok) return toast(r.error);
      drawEvents(r); toast("Нагадаю, коли дадуть світло");
    });
  }

  function sheet(html) {
    closeSheet();
    const bg = document.createElement("div");
    bg.className = "sheet-bg"; bg.id = "sheet";
    bg.innerHTML = `<div class="sheet" role="dialog" aria-modal="true">${html}</div>`;
    bg.addEventListener("click", (e) => { if (e.target === bg || e.target.closest("[data-close]")) closeSheet(); });
    document.body.appendChild(bg); document.body.style.overflow = "hidden";
    return bg;
  }
  function closeSheet() { const s = $("#sheet"); if (s) s.remove(); document.body.style.overflow = ""; }

  const TEMPLATES = [
    ["🩺 Лікар", { title: "Лікар", tm: "10:00", remind: [1440, 60] }],
    ["🚗 До мами", { title: "Поїздка до мами", tm: "11:00", remind: [1440] }],
    ["🎂 День народження", { title: "День народження ", tm: "", rep: "yearly", remind: [10080, 1440] }],
    ["💳 Оплатити рахунки", { title: "Оплатити комуналку", tm: "", rep: "monthly", remind: [0] }],
  ];
  function eventSheet(ev) {
    const e = ev || { title: "", day: today(), tm: "", rep: "none", remind: [60], who: null, notes: "" };
    const ms = st.ev ? st.ev.members : [];
    const s = sheet(`<h2>${ev ? "Подія" : "Нова подія"}<button class="icon" data-close aria-label="Закрити">${ICON.x}</button></h2>
      ${ev ? "" : `<div class="tpl">${TEMPLATES.map(([l], i) => `<button type="button" data-tpl="${i}">${l}</button>`).join("")}</div>`}
      <label class="field"><span>Що</span><input id="e-title" value="${esc(e.title)}" placeholder="Напр.: стоматолог, поїздка до мами"></label>
      <div class="row2">
        <label class="field"><span>Дата</span><input id="e-day" type="date" value="${e.day}"></label>
        <label class="field"><span>Час</span><input id="e-tm" type="time" value="${e.tm || ""}" ${e.tm ? "" : "disabled"}></label>
      </div>
      <label class="check"><input type="checkbox" id="e-allday" ${e.tm ? "" : "checked"}> Весь день (нагадаю о 9:00)</label>
      <div class="row2">
        <label class="field"><span>Повтор</span><select id="e-rep">${Object.entries({ none: "Не повторювати", weekly: "Щотижня", monthly: "Щомісяця", yearly: "Щороку" }).map(([k, l]) => `<option value="${k}" ${k === e.rep ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label class="field"><span>Для кого</span><select id="e-who"><option value="">Для всіх</option>${ms.map((m) => `<option value="${m.id}" ${m.id === e.who ? "selected" : ""}>${esc(m.name)}</option>`).join("")}</select></label>
      </div>
      <div class="field"><span>Нагадати в Telegram</span><div class="toggles" id="e-rem">${REMINDS.map(([v, l]) => `<button type="button" data-v="${v}" aria-pressed="${e.remind.includes(v)}">${l}</button>`).join("")}</div></div>
      <label class="field"><span>Нотатка</span><input id="e-notes" value="${esc(e.notes)}" placeholder="Адреса, кабінет, що взяти"></label>
      <div class="foot">${ev ? `<button class="btn light danger" data-del="${ev.id}">Видалити</button>` : ""}<button class="btn lamp" id="e-save">Зберегти</button></div>`);
    const allday = $("#e-allday", s), tm = $("#e-tm", s);
    allday.addEventListener("change", () => { tm.disabled = allday.checked; if (!allday.checked && !tm.value) tm.value = "10:00"; });
    $("#e-rem", s).addEventListener("click", (x) => { const b = x.target.closest("[data-v]"); if (b) b.setAttribute("aria-pressed", b.getAttribute("aria-pressed") !== "true"); });
    s.addEventListener("click", (x) => {
      const t = x.target.closest("[data-tpl]"); if (!t) return;
      const v = TEMPLATES[+t.dataset.tpl][1];
      $("#e-title", s).value = v.title; $("#e-rep", s).value = v.rep || "none";
      allday.checked = !v.tm; tm.disabled = !v.tm; tm.value = v.tm || "";
      s.querySelectorAll("#e-rem [data-v]").forEach((b) => b.setAttribute("aria-pressed", v.remind.includes(+b.dataset.v)));
      $("#e-title", s).focus();
    });
    const del = s.querySelector("[data-del]");
    if (del) del.addEventListener("click", async () => {
      if (del.dataset.sure !== "1") { del.dataset.sure = "1"; del.textContent = "Точно видалити?"; return; }
      const r = await call("event_delete", { id: +del.dataset.del }); if (!r.ok) return toast(r.error);
      closeSheet(); drawEvents(r); toast("Видалено");
    });
    $("#e-save", s).addEventListener("click", async () => {
      const event = { id: ev?.id, title: $("#e-title", s).value, day: $("#e-day", s).value, tm: allday.checked ? null : tm.value, rep: $("#e-rep", s).value,
        who: $("#e-who", s).value ? +$("#e-who", s).value : null, notes: $("#e-notes", s).value,
        remind: [...s.querySelectorAll('#e-rem [aria-pressed="true"]')].map((b) => +b.dataset.v) };
      const r = await call("event_save", { event }); if (!r.ok) return toast(r.error);
      closeSheet(); if (!(st.tab === "more" && st.more === "events")) { st.tab = "more"; st.more = "events"; await renderEvents(); } else drawEvents(r); toast("Збережено");
    });
    if (!ev) setTimeout(() => $("#e-title", s)?.focus(), 50);
  }

  // ───── Світло: відключення і витрати ─────
  const lightHead = () => `<div class="head"><h1>Світло</h1></div>
    <div class="seg" role="group" aria-label="Розділ"><button data-act="lightView" data-v="out" aria-pressed="${st.light === "out"}">Відключення</button><button data-act="lightView" data-v="money" aria-pressed="${st.light === "money"}">Витрати</button><button data-act="lightView" data-v="charge" aria-pressed="${st.light === "charge"}">Зарядка ЖК</button></div>`;
  function periodRange() {
    if (st.period === "week") { const d = D(st.anchor); const wd = (d.getDay() + 6) % 7; const f = addDays(st.anchor, -wd); return [f, addDays(f, 6)]; }
    const f = st.anchor.slice(0, 8) + "01"; const e = D(f); e.setMonth(e.getMonth() + 1); e.setDate(0); return [f, iso(e)];
  }
  async function renderOutages() {
    const [from, to] = periodRange();
    const lbl = st.period === "week" ? `${D(from).getDate()}.${pad(D(from).getMonth() + 1)} – ${D(to).getDate()}.${pad(D(to).getMonth() + 1)}` : `${MONN[D(from).getMonth()]} ${D(from).getFullYear()}`;
    shell(`${lightHead()}
      <div class="nav-date"><button class="icon" data-act="shift" data-n="-1" aria-label="Назад">${ICON.left}</button><div class="l">${lbl}<button class="link" data-act="period" data-p="${st.period === "week" ? "month" : "week"}">${st.period === "week" ? "місяць" : "тиждень"}</button></div><button class="icon" data-act="shift" data-n="1" aria-label="Вперед">${ICON.right}</button></div>
      <div id="obox"><div class="empty">Завантаження…</div></div>`);
    const j = await must("outages", { from, to });
    const box = $("#obox"); if (!box) return;
    const nowMs = j.now, os = j.outages, als = j.alerts || [];
    const days = []; for (let d = from; d <= to; d = addDays(d, 1)) days.push(d);
    const minutesOn = (d) => { const a = D(d).getTime(), b = a + 86400000; return os.reduce((s, o) => s + Math.max(0, Math.min(b, o.ended_at ? Date.parse(o.ended_at) : nowMs) - Math.max(a, Date.parse(o.started_at))), 0) / 60000; };
    const total = days.reduce((s, d) => s + minutesOn(d), 0);
    const longest = os.reduce((m, o) => Math.max(m, ((o.ended_at ? Date.parse(o.ended_at) : nowMs) - Date.parse(o.started_at)) / 60000), 0);
    const rows = days.map((d) => {
      const m = minutesOn(d);
      const ac = als.length ? stripFromOutages(d, als, nowMs).map((x) => (x === "off" ? "a" : "")) : null;
      return `<div class="srow"><div class="d">${WD[D(d).getDay()]}<small>${D(d).getDate()}.${pad(D(d).getMonth() + 1)}</small></div><div class="stack">${stripHtml(stripFromOutages(d, os, nowMs), `${dLong(d)}: без світла ${dur(m)}`)}${ac ? `<div class="astrip" aria-hidden="true">${ac.map((x) => `<i class="${x}"></i>`).join("")}</div>` : ""}</div><div class="t">${D(d).getTime() > nowMs ? "" : m ? durShort(m) : "—"}</div></div>`;
    }).join("");
    // Дві стрічки подій: коли вимкнули і коли увімкнули (новіші зверху, по днях)
    const sorted = [...os].sort((x, y) => Date.parse(x.started_at) - Date.parse(y.started_at));
    const offEv = sorted.map((o, i) => {
      const t = Date.parse(o.started_at), e = o.ended_at ? Date.parse(o.ended_at) : null;
      const prevEnd = i > 0 && sorted[i - 1].ended_at ? Date.parse(sorted[i - 1].ended_at) : null;
      return { t, main: e ? `без світла ${dur((e - t) / 60000)}` : `<span class="tag now">досі немає · ${dur((nowMs - t) / 60000)}</span>`,
        sub: [prevEnd ? `перед цим світло було ${dur((t - prevEnd) / 60000)}` : "", o.soc_start != null ? `АКБ ${Math.round(o.soc_start)}%` : ""].filter(Boolean).join(" · ") };
    });
    const onEv = sorted.filter((o) => o.ended_at).map((o) => {
      const i = sorted.indexOf(o), t = Date.parse(o.ended_at), s0 = Date.parse(o.started_at), nx = sorted[i + 1];
      const until = nx ? Date.parse(nx.started_at) : null;
      return { t, main: until ? `світло було ${dur((until - t) / 60000)}` : `<span class="tag on">є досі · ${dur((nowMs - t) / 60000)}</span>`,
        sub: [`після ${dur((t - s0) / 60000)} без світла`, o.soc_min != null ? `АКБ мін. ${Math.round(o.soc_min)}%` : ""].filter(Boolean).join(" · ") };
    });
    const evList = (evs, emptyTxt) => {
      if (!evs.length) return `<div class="empty">${emptyTxt}</div>`;
      let html = "", last = "";
      for (const e of [...evs].reverse()) {
        const d = iso(new Date(e.t));
        if (d !== last) { html += `<li class="eday">${d === today() ? "Сьогодні" : d === addDays(today(), -1) ? "Вчора" : `${WD[D(d).getDay()]}, ${dLong(d)}`}</li>`; last = d; }
        html += `<li class="ev"><b class="tm">${hm(e.t)}</b><span class="w">${e.main}${e.sub ? `<span class="sub">${e.sub}</span>` : ""}</span></li>`;
      }
      return `<ul class="evlist">${html}</ul>`;
    };
    box.innerHTML = `
      <div class="kpis" style="margin-top:0">
        <div class="kpi" style="background:var(--surface)"><b>${durShort(total)}</b><span>без світла</span></div>
        <div class="kpi" style="background:var(--surface)"><b>${os.length}</b><span>відключень</span></div>
        <div class="kpi" style="background:var(--surface)"><b>${durShort(longest)}</b><span>найдовше</span></div>
      </div>
      <section class="panel"><h2>Графік</h2>${als.length ? '<div class="legend" style="margin:-4px 0 10px"><span><i style="background:var(--strip-off)"></i>без світла</span><span><i style="background:var(--raid)"></i>тривога</span></div>' : ""}<div class="sched">${rows}</div><div class="hours" aria-hidden="true"><span></span><div><span>0</span><span>6</span><span>12</span><span>18</span><span>24</span></div><span></span></div></section>
      <div class="evcols">
        <section class="panel"><h2 class="row"><span>🕯 Вимкнення</span><em>${offEv.length}</em></h2>${evList(offEv, "За цей період світло не вимикали")}</section>
        <section class="panel"><h2 class="row"><span>💡 Увімкнення</span><em>${onEv.length}</em></h2>${evList(onEv, "За цей період світло не вмикали")}</section>
      </div>`;
  }
  async function renderMoney() {
    const m = st.month, f = m + "-01", e = (() => { const x = D(f); x.setMonth(x.getMonth() + 1); x.setDate(0); return iso(x); })();
    shell(`${lightHead()}
      <div class="nav-date"><button class="icon" data-act="mshift" data-n="-1" aria-label="Попередній місяць">${ICON.left}</button><div class="l">${MONN[D(f).getMonth()]} ${D(f).getFullYear()}</div><button class="icon" data-act="mshift" data-n="1" aria-label="Наступний місяць">${ICON.right}</button></div>
      <div id="mbox"><div class="empty">Завантаження…</div></div>`);
    if (!st.settings.tariff_day) { const d = await must("dashboard"); st.settings = d.settings; st.me = d.me; }
    const j = await must("daily", { from: f, to: e });
    const box = $("#mbox"); if (!box) return;
    const ds = j.days, by = Object.fromEntries(ds.map((d) => [d.day, d]));
    const sum = (k) => ds.reduce((a, d) => a + (d[k] || 0), 0);
    const cost = sum("grid_cost"), grid = sum("grid_kwh"), est = ds.some((d) => d.grid_estimated);
    const days = []; for (let d = f; d <= e; d = addDays(d, 1)) days.push(d);
    const max = Math.max(1, ...days.map((d) => (by[d] ? by[d].grid_cost : 0)));
    const s = st.settings;
    const pvSave = sum("pv_kwh") * (s.tariff_day || 4.32);
    box.innerHTML = `
      <section class="panel">
        <div class="money"><b>${num(cost)}</b><span>грн за світло з мережі</span></div>
        <div class="muted">${num(grid, 1)} кВт·год · тариф ${s.tariff_zones ? `${num(s.tariff_day, 2)} / ${num(s.tariff_night, 2)} (ніч)` : num(s.tariff_day || 4.32, 2)} грн</div>
        <div class="bars" role="img" aria-label="Вартість по днях">${days.map((d) => `<div class="${by[d]?.grid_estimated ? "est" : ""}" style="height:${((by[d]?.grid_cost || 0) / max) * 100}%" title="${dLong(d)}: ${num(by[d]?.grid_cost || 0)} грн"></div>`).join("")}</div>
        <div class="bars-x">${days.map((d, i) => `<span>${i % 5 === 0 || i === days.length - 1 ? D(d).getDate() : ""}</span>`).join("")}</div>
        ${est ? '<p class="note">Інвертор не передає споживання з мережі напряму, тому воно розраховане: навантаження + заряд АКБ − сонце. Похибка зазвичай до 10%.</p>' : ""}
      </section>
      <section class="panel"><h2>Енергія за місяць</h2><div class="rows">
        <div><span>Спожито в будинку</span><b>${num(sum("load_kwh"), 1)} кВт·год</b></div>
        <div><span>З мережі</span><b>${num(grid, 1)} кВт·год</b></div>
        <div><span>Від сонця</span><b>${num(sum("pv_kwh"), 1)} кВт·год</b></div>
        <div><span>Віддала АКБ у відключення</span><b>${num(sum("batt_out_kwh"), 1)} кВт·год</b></div>
        <div><span>Без світла</span><b>${durShort(sum("outage_min"))}</b></div>
        ${pvSave > 1 ? `<div><span>Зекономило сонце</span><b>≈ ${num(pvSave)} грн</b></div>` : ""}
      </div></section>`;
  }

  // ───── Зарядка ЖК (через бот зарядки під'їзду) ─────
  const kwF = (x) => (Math.round(x * 100) / 100).toString().replace(".", ",");
  const tsT = (s) => { const d = iso(new Date(s * 1000)); return (d === today() ? "" : d === addDays(today(), 1) ? "завтра " : dLong(d) + " ") + hm(s * 1000); };
  const loadBar = (cur, lim) => `<div class="lbar" role="img" aria-label="Навантаження ${kwF(cur)} з ${kwF(lim)} кВт"><i style="width:${Math.min(100, (cur / lim) * 100)}%"></i></div>`;
  function chargeCard(c) {
    if (!c) return "";
    const m = c.mine, q = c.my_queue;
    const line = m ? `<b>${kwF(m.kw)} кВт</b> ${m.start_ts > c.now ? `з ${tsT(m.start_ts)}` : m.end_ts <= c.now ? '<span class="tag now">час вийшов — відмітьтесь</span>' : `до ${tsT(m.end_ts)}`}`
      : q ? (q.status === "offered" ? '<span class="tag now">звільнилось місце — підтвердіть</span>' : `у черзі: ${q.pos}-а`) : c.gen_on ? "можна бронювати" : "генератор не працює";
    return `<section class="panel tap" data-act="goCharge"><h2 class="row"><span>${ICON.socket}Зарядка ЖК</span><em>${kwF(c.load)} / ${kwF(c.limit)} кВт</em></h2>${loadBar(c.load, c.limit)}<p class="note" style="margin:8px 0 0">${line}</p></section>`;
  }
  const CH = { kw: null, start: 0, dur: 60 };
  async function renderCharge() {
    shell(`${lightHead()}<div id="cbox"><div class="empty">Завантаження…</div></div>`);
    drawCharge(await must("charging"));
  }
  function drawCharge(j) {
    st.charge = j;
    const box = $("#cbox"); if (!box) return;
    if (!j.linked) {
      box.innerHTML = `<section class="panel"><h2>Привʼяжіть свій Telegram</h2>
        <p style="margin:0 0 12px">Зарядку від генератора бронюють через бот ЖК. Щоб робити це звідси, «Світлиця» має знати ваш Telegram.</p>
        <button class="btn lamp" data-act="tgMe">${ICON.tg} Привʼязати Telegram</button>
        <p class="note">Відкриється бот «Світлиці» — натисніть «Start», і все.</p></section>`;
      return;
    }
    const s = j.status;
    if (!s.registered) {
      box.innerHTML = `<section class="panel"><h2>Ви ще не в боті зарядки ЖК</h2>
        ${j.family_apartment ? `<p style="margin:0 0 12px">Ваша сімʼя бронює на кв. ${esc(j.family_apartment.apartment)}. Записати вас до цієї квартири?</p><button class="btn lamp" data-act="chRegister">Записати до кв. ${esc(j.family_apartment.apartment)}</button>`
          : '<p style="margin:0">Відкрийте бот зарядки ЖК у Telegram, натисніть «Start» і вкажіть квартиру. Потім поверніться сюди.</p>'}</section>`;
      return;
    }
    const now = s.now, mine = s.bookings.find((b) => b.mine), mq = s.my_queue;
    const nowB = s.bookings.filter((b) => b.start_ts <= now), fut = s.bookings.filter((b) => b.start_ts > now);
    const row = (b) => `<li class="${b.mine ? "mine" : ""}"><span>кв. ${esc(b.apartment)}${b.mine ? " (ми)" : ""}</span><span>${kwF(b.kw)} кВт</span><span>${b.start_ts > now ? `${tsT(b.start_ts)}–${tsT(b.end_ts)}` : b.end_ts <= now ? '<span class="tag now">прострочено</span>' : `до ${tsT(b.end_ts)}`}</span></li>`;
    if (CH.kw == null || !s.kw_options.includes(CH.kw)) CH.kw = s.kw_options.includes(0.5) ? 0.5 : s.kw_options[0];
    if (!s.dur_options.includes(CH.dur)) CH.dur = s.dur_options[0];
    const chips = (name, opts, cur, fmt) => `<div class="toggles">${opts.map((v) => `<button data-act="chPick" data-k="${name}" data-v="${v}" aria-pressed="${v === cur}">${fmt(v)}</button>`).join("")}</div>`;
    let my = "";
    if (mine) {
      const over = mine.end_ts <= now, futb = mine.start_ts > now;
      my = `<section class="panel mybook ${over ? "over" : ""}"><h2>Наша бронь · кв. ${esc(s.apartment)}</h2>
        <div class="big2">${kwF(mine.kw)} кВт <small>${futb ? `${tsT(mine.start_ts)}–${tsT(mine.end_ts)}` : over ? `час вийшов о ${tsT(mine.end_ts)}` : `до ${tsT(mine.end_ts)}`}</small></div>
        <div class="row3"><button class="btn ${futb ? "light" : "lamp"}" data-act="chDone" data-id="${mine.id}">${futb ? "Скасувати" : "Зняли із зарядки"}</button>${futb ? "" : `<button class="btn light" data-act="chExt" data-id="${mine.id}" data-m="30">+30 хв</button><button class="btn light" data-act="chExt" data-id="${mine.id}" data-m="60">+1 год</button>`}</div></section>`;
    } else if (mq) {
      my = `<section class="panel mybook"><h2>Ми в черзі · кв. ${esc(s.apartment)}</h2>
        ${mq.status === "offered" ? `<p style="margin:0 0 12px"><b>Звільнилось ${kwF(mq.kw)} кВт!</b> Підтвердіть до ${tsT(mq.offer_until)}, інакше місце перейде далі.</p><div class="row2"><button class="btn lamp" data-act="chTake" data-id="${mq.id}">Беру</button><button class="btn light" data-act="chLeave" data-id="${mq.id}">Вийти з черги</button></div>`
          : `<p style="margin:0 0 12px">${mq.pos}-а в черзі · ${kwF(mq.kw)} кВт на ${dur(mq.dur / 60)}. Повідомлю, щойно звільниться місце.</p><button class="btn light" data-act="chLeave" data-id="${mq.id}">Вийти з черги</button>`}</section>`;
    } else if (s.gen_on) {
      my = `<section class="panel"><h2>Забронювати · кв. ${esc(s.apartment)}</h2>
        <div class="field"><span>Потужність</span>${chips("kw", s.kw_options, CH.kw, (v) => kwF(v) + " кВт")}</div>
        <p class="note" style="margin:-4px 0 12px">Телефон ≈ 0,02 · павербанк 0,05 · ноутбук 0,1 · зарядна станція 0,3–1,5 кВт</p>
        <div class="field"><span>Коли</span>${chips("start", [0, 30, 60], CH.start, (v) => (v ? `через ${v === 60 ? "1 год" : v + " хв"}` : "Зараз"))}</div>
        <div class="field"><span>На скільки</span>${chips("dur", s.dur_options, CH.dur, (v) => dur(v))}</div>
        <button class="btn lamp" data-act="chBook">Забронювати</button><div id="ch-res"></div></section>`;
    }
    box.innerHTML = `
      <section class="panel"><h2 class="row"><span>${s.gen_on ? "🟢 Генератор працює" : "⚪ Генератор вимкнено"}</span><em>вільно ${kwF(Math.max(0, s.limit - s.load))} кВт</em></h2>
        ${loadBar(s.load, s.limit)}<div class="lbl"><b>${kwF(s.load)}</b> з ${kwF(s.limit)} кВт зараз</div></section>
      ${my}
      <section class="panel"><h2>Заряджаються зараз</h2>${nowB.length ? `<ul class="clist">${nowB.map(row).join("")}</ul>` : '<p class="note" style="margin:0">Нікого — розетка вільна.</p>'}
        ${fut.length ? `<h2 style="margin-top:14px">Заплановано</h2><ul class="clist">${fut.map(row).join("")}</ul>` : ""}
        ${s.queue.length ? `<h2 style="margin-top:14px">Черга</h2><ul class="clist">${s.queue.map((q) => `<li class="${q.mine ? "mine" : ""}"><span>${q.pos}. кв. ${esc(q.apartment)}</span><span>${kwF(q.kw)} кВт</span><span>${dur(q.dur / 60)}</span></li>`).join("")}</ul>` : ""}
      </section>
      ${s.today.length ? `<section class="panel"><h2>Сьогодні спожито</h2><ul class="clist">${s.today.slice(0, 8).map((x) => `<li class="${x.apartment === s.apartment ? "mine" : ""}"><span>кв. ${esc(x.apartment)}</span><span></span><span>${kwF(x.kwh)} кВт·год</span></li>`).join("")}</ul></section>` : ""}
      <p class="credit">Дані бота зарядки ЖК. Нагадування «час вийшов» приходять від нього в Telegram.</p>`;
  }

  // ───── Погода й якість повітря (Open-Meteo, без ключа) ─────
  const WX_PLACES = [["home", "Крюківщина", 50.383, 30.374], ["dacha", "Хотянівка", 50.596, 30.567], ["kyiv", "Київ", 50.450, 30.524]];
  const WMO = { 0: ["☀️", "ясно"], 1: ["🌤", "переважно ясно"], 2: ["⛅", "мінлива хмарність"], 3: ["☁️", "хмарно"], 45: ["🌫", "туман"], 48: ["🌫", "туман з інеєм"],
    51: ["🌦", "легка мряка"], 53: ["🌦", "мряка"], 55: ["🌧", "сильна мряка"], 56: ["🌧", "крижана мряка"], 57: ["🌧", "крижана мряка"], 61: ["🌦", "невеликий дощ"], 63: ["🌧", "дощ"], 65: ["🌧", "сильний дощ"],
    66: ["🌧", "крижаний дощ"], 67: ["🌧", "крижаний дощ"], 71: ["🌨", "невеликий сніг"], 73: ["🌨", "сніг"], 75: ["❄️", "сильний сніг"], 77: ["🌨", "снігова крупа"], 80: ["🌦", "злива"], 81: ["🌧", "зливи"], 82: ["⛈", "сильні зливи"],
    85: ["🌨", "снігопад"], 86: ["❄️", "сильний снігопад"], 95: ["⛈", "гроза"], 96: ["⛈", "гроза з градом"], 99: ["⛈", "гроза з градом"] };
  const wmo = (c, day = 1) => { const w = WMO[c] || ["🌡", "—"]; return !day && (c === 0 || c === 1) ? ["🌙", w[1]] : w; };
  const AQI = (v) => v == null ? ["—", ""] : v <= 20 ? ["добре", "a1"] : v <= 40 ? ["задовільне", "a2"] : v <= 60 ? ["помірне", "a3"] : v <= 80 ? ["погане", "a4"] : v <= 100 ? ["дуже погане", "a5"] : ["надзвичайно погане", "a6"];
  const aqiAdvice = (v) => v == null ? "" : v > 80 ? "Зачиніть вікна, вимкніть припливну вентиляцію, прогулянки краще відкласти. Для дітей і літніх — особливо." : v > 60 ? "Повітря погане: провітрювати не варто, на вулиці — коротше, чутливим людям краще бути вдома." : v > 40 ? "Чутливим людям (астма, діти) варто обмежити тривале перебування надворі." : "Можна провітрювати й гуляти.";
  const sunLvl = (mj) => mj == null ? "" : mj >= 12 ? "☀️ багато сонця для панелей" : mj >= 5 ? "🌤 середньо сонця" : "☁️ мало сонця";
  const wxPlace = () => { let k = "home"; try { k = localStorage.getItem("svit-wx-place") || "home"; } catch {} return k; };
  const wxMem = {};
  async function wxGet(key) {
    if (DEMO && window.DemoBackend && window.DemoBackend.weather) return window.DemoBackend.weather(key);
    let lat, lon, name;
    if (key === "me") {
      let c = null; try { c = JSON.parse(localStorage.getItem("svit-wx-me") || "null"); } catch {}
      if (!c || Date.now() - c.t > 30 * 60000) c = await new Promise((ok, no) => navigator.geolocation ? navigator.geolocation.getCurrentPosition((p) => ok({ lat: p.coords.latitude, lon: p.coords.longitude, t: Date.now() }), no, { timeout: 12000, maximumAge: 600000 }) : no(new Error("geo")));
      try { localStorage.setItem("svit-wx-me", JSON.stringify(c)); } catch {}
      lat = c.lat; lon = c.lon; name = "Де я зараз";
    } else { const p = WX_PLACES.find((x) => x[0] === key) || WX_PLACES[0]; [, name, lat, lon] = p; }
    const ck = `${lat.toFixed(2)},${lon.toFixed(2)}`;
    if (wxMem[ck] && Date.now() - wxMem[ck].t < 10 * 60000) return { ...wxMem[ck].d, name };
    const q = `latitude=${lat}&longitude=${lon}&timezone=Europe%2FKyiv`;
    const [w, a] = await Promise.all([
      fetch(`https://api.open-meteo.com/v1/forecast?${q}&forecast_days=7&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,wind_gusts_10m,precipitation,is_day&hourly=temperature_2m,precipitation_probability,weather_code,is_day&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,shortwave_radiation_sum,wind_gusts_10m_max`).then((r) => r.json()),
      fetch(`https://air-quality-api.open-meteo.com/v1/air-quality?${q}&forecast_days=2&current=european_aqi,pm2_5,pm10,nitrogen_dioxide,ozone&hourly=european_aqi`).then((r) => r.json()).catch(() => null),
    ]);
    if (!w || !w.current) throw new Error("wx");
    const d = { w, a }; wxMem[ck] = { t: Date.now(), d };
    return { ...d, name };
  }
  function wxCard(x) {
    const c = x.w.current, [ic, tx] = wmo(c.weather_code, c.is_day), aq = x.a && x.a.current ? x.a.current.european_aqi : null, [al, acls] = AQI(aq);
    const td = x.w.daily;
    return `<section class="panel tap wxcard" data-act="goMore" data-p="weather"><div class="wxnow"><span class="wxi">${ic}</span><div><b>${Math.round(c.temperature_2m)}°</b><small>${esc(x.name)} · ${tx}</small></div>
      <div class="wxr"><small>${Math.round(td.temperature_2m_min[0])}° / ${Math.round(td.temperature_2m_max[0])}°${td.precipitation_probability_max[0] >= 30 ? ` · 💧${td.precipitation_probability_max[0]}%` : ""}</small>${aq != null ? `<span class="aqi ${acls}">повітря ${al} · ${aq}</span>` : ""}</div></div></section>`;
  }
  async function renderWeather() {
    const k = st.wx || wxPlace();
    const seg = `<div class="seg mseg" role="group" aria-label="Місце">${[...WX_PLACES.map((p) => [p[0], p[1]]), ["me", "📍 Я"]].map(([v, l]) => `<button data-act="wxPlace" data-v="${v}" aria-pressed="${k === v}">${l}</button>`).join("")}</div>`;
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Погода й повітря</h1></div>${seg}<div class="empty">Завантаження…</div>`);
    let x; try { x = await wxGet(k); } catch { shell(`<div class="head">${back("goMenu")}<h1 class="grow">Погода й повітря</h1></div>${seg}<div class="panel empty">${k === "me" ? "Дозвольте доступ до геолокації, щоб показати погоду там, де ви." : "Не вдалося завантажити погоду. Перевірте інтернет."}</div>`); return; }
    const c = x.w.current, [ic, tx] = wmo(c.weather_code, c.is_day), A = x.a && x.a.current, aq = A ? A.european_aqi : null, [al, acls] = AQI(aq);
    const H = x.w.hourly, now = Date.now(), hi = H.time.findIndex((t) => Date.parse(t) >= now - 3600000);
    const hours = H.time.slice(hi, hi + 24).map((t, i) => { const j = hi + i, [hic] = wmo(H.weather_code[j], H.is_day[j]); return `<div class="wxh"><small>${t.slice(11, 13)}</small><span>${hic}</span><b>${Math.round(H.temperature_2m[j])}°</b>${H.precipitation_probability[j] >= 20 ? `<em>${H.precipitation_probability[j]}%</em>` : "<em></em>"}</div>`; }).join("");
    const aqH = x.a && x.a.hourly ? x.a.hourly.european_aqi.slice(hi, hi + 24).filter((v) => v != null) : [], aqMax = aqH.length ? Math.max(...aqH) : null;
    const D2 = x.w.daily, WDs = ["Нд", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
    const days = D2.time.map((d, i) => { const [dic, dtx] = wmo(D2.weather_code[i]); return `<li><span class="wd">${i === 0 ? "Сьогодні" : i === 1 ? "Завтра" : `${WDs[new Date(d + "T12:00").getDay()]} ${d.slice(8)}.${d.slice(5, 7)}`}</span><span class="wi" title="${dtx}">${dic}</span><span class="wp">${D2.precipitation_probability_max[i] >= 20 ? `💧${D2.precipitation_probability_max[i]}%` : ""}</span><span class="wt"><small>${Math.round(D2.temperature_2m_min[i])}°</small> ${Math.round(D2.temperature_2m_max[i])}°</span><small class="ws">${sunLvl(D2.shortwave_radiation_sum[i])}</small></li>`; }).join("");
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Погода й повітря</h1></div>${seg}
      <section class="panel"><div class="wxnow big"><span class="wxi">${ic}</span><div><b>${Math.round(c.temperature_2m)}°</b><small>${esc(x.name)} · ${tx}</small></div></div>
        <ul class="flist"><li><span>Відчувається як</span><b>${Math.round(c.apparent_temperature)}°</b></li><li><span>Вітер</span><b>${Math.round(c.wind_speed_10m)} км/год${c.wind_gusts_10m >= 40 ? `, пориви ${Math.round(c.wind_gusts_10m)}` : ""}</b></li><li><span>Вологість</span><b>${c.relative_humidity_2m}%</b></li><li><span>Схід / захід</span><b>${D2.sunrise[0].slice(11)} / ${D2.sunset[0].slice(11)}</b></li></ul></section>
      <section class="panel"><h2 class="row"><span>🌬 Якість повітря</span>${aq != null ? `<span class="aqi ${acls}">${al}</span>` : ""}</h2>
        ${A ? `<div class="money"><b>${aq}</b><span>EAQI</span></div><div class="aqbar"><i style="left:${Math.min(100, aq)}%"></i></div>
          <ul class="flist"><li><span>PM2.5</span><b>${A.pm2_5 ?? "—"} мкг/м³</b></li><li><span>PM10</span><b>${A.pm10 ?? "—"} мкг/м³</b></li><li><span>NO₂</span><b>${A.nitrogen_dioxide ?? "—"} мкг/м³</b></li><li><span>Озон</span><b>${A.ozone ?? "—"} мкг/м³</b></li></ul>
          <p class="note" style="margin:8px 0 0">${aqiAdvice(Math.max(aq, 0))}${aqMax != null && aqMax > aq + 10 ? ` Протягом доби може погіршитись до ${aqMax} (${AQI(aqMax)[0]}).` : ""}</p>` : '<p class="note" style="margin:0">Дані про повітря зараз недоступні.</p>'}</section>
      <section class="panel" style="padding-right:0"><h2>Найближчі 24 години</h2><div class="wxhours">${hours}</div></section>
      <section class="panel"><h2>7 днів</h2><ul class="wxdays">${days}</ul></section>
      <p class="credit">Дані: <a href="https://open-meteo.com" target="_blank" rel="noopener">Open-Meteo</a> (CC BY 4.0), модель якості повітря CAMS. ${k !== "me" && k !== wxPlace() ? '<button class="link" data-act="wxDefault">зробити основним</button>' : ""}</p>`);
  }

  // ───── Віджет на головний екран Android (KWGT) ─────
  const WIDGET_URL = (window.WIDGET_API || API_URL.replace(/\/energy\/?$/, "/svit-widget")).trim();
  async function callWidget(action) {
    if (DEMO) return { ok: true, active: false, url: "https://…/svit-widget?k=DEMO", preview: { light_line: "💡 Світло є · 3 год 10 хв", soc_txt: "98%", alert: "🔴 Тривога · Київська обл.", me: "🟢 Тихо · Київ", line: "💡 Світло є · АКБ 98% · 🔴 тривога" } };
    try { const r = await fetch(WIDGET_URL, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + token }, body: JSON.stringify({ action }) }); return await r.json(); }
    catch { return { ok: false, error: "Немає звʼязку з сервером" }; }
  }
  async function renderWidget(made) {
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Віджет на телефон</h1></div><div class="empty">Завантаження…</div>`);
    const j = made || await callWidget("widget_status");
    if (!j.ok) { toast(j.error || "Помилка"); return; }
    const p = j.preview || {}, url = j.url || "";
    const f = (path) => url ? `$wg("${url}", json, ".${path}")$` : `$wg("ПОСИЛАННЯ", json, ".${path}")$`;
    st.wUrl = url;
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Віджет на телефон</h1></div>
      <section class="panel"><h2>Так виглядатиме</h2>
        <div class="wprev"><b>${esc(p.light_line || "—")}</b><span>🔋 АКБ ${esc(p.soc_txt || "—")}</span><span>${esc(p.alert || "")}</span>${p.me ? `<span>${esc(p.me)}${p.threats ? ` · ${esc(p.threats)}` : ""}</span>` : ""}</div>
      </section>
      <section class="panel"><h2>1. Особисте посилання</h2>
        ${url ? `<p class="note" style="margin:0 0 8px">Скопіюйте й нікому не пересилайте — за ним видно стан світла й тривоги вашого дому.</p><div class="invite"><input readonly value="${esc(url)}" aria-label="Посилання віджета"><div class="row2" style="margin-top:8px"><button class="btn light" data-act="wCopy" data-v="url">Копіювати посилання</button><button class="btn light danger" data-act="wOff">Вимкнути</button></div></div>`
          : `<p class="note" style="margin:0 0 10px">${j.active ? "Посилання вже створене. Якщо загубили — створіть нове (старе перестане працювати)." : "Посилання потрібне, щоб віджет брав дані зі «Світлиці» без пароля."}</p><button class="btn lamp" data-act="wMake">${j.active ? "Створити нове посилання" : "Створити посилання"}</button>${j.active ? '<button class="btn light danger" data-act="wOff" style="margin-top:8px">Вимкнути віджет</button>' : ""}`}
      </section>
      <section class="panel"><h2>2. Віджет у KWGT (Samsung / Android)</h2>
        <ol class="steps">
          <li>Встановіть з Google Play <b>KWGT Kustom Widget Maker</b>.</li>
          <li>Довго натисніть на порожнє місце головного екрана → <b>Віджети</b> → <b>KWGT</b> → розмір 4×1 або 4×2.</li>
          <li>Торкніться порожнього віджета → <b>створити новий</b> (пустий шаблон).</li>
          <li>Додайте елемент <b>Текст</b> (+ → Text) → у полі тексту натисніть <b>калькулятор (формула)</b> і вставте формулу нижче.</li>
          <li>Збережіть (дискета зверху). Готово — віджет оновлюватиметься сам.</li>
        </ol>
        <p class="note" style="margin:6px 0 6px"><b>Один рядок</b> (найпростіше):</p>
        <div class="formula"><code>${esc(f("line"))}</code><button class="link" data-act="wCopy" data-v="line">копіювати</button></div>
        <p class="note" style="margin:10px 0 6px"><b>Або окремі рядки</b> — кожен окремим елементом «Текст»:</p>
        ${[["light_line", "світло і скільки часу"], ["soc_txt", "заряд АКБ"], ["alert", "тривога вдома"], ["me", "тривога там, де я"], ["threats", "що летить"]].map(([k, l]) => `<div class="formula"><small>${l}</small><code>${esc(f(k))}</code><button class="link" data-act="wCopy" data-v="${k}">копіювати</button></div>`).join("")}
        <p class="note" style="margin:10px 0 0">Частота оновлення — у налаштуваннях KWGT (оновлення даних з інтернету, наприклад раз на 15 хв). Натискання на віджет може відкривати «Світлицю»: Дія при натисканні → Запустити застосунок → браузер / ярлик «Світлиці».</p>
      </section>
      <section class="panel"><h2>Для годинника</h2><p class="note" style="margin:0">Сповіщення про світло й тривогу з Telegram уже приходять на Galaxy Watch — увімкніть Telegram у Galaxy Wearable → Сповіщення.</p></section>`);
  }

  // ───── Ще: тривоги, сімʼя, налаштування ─────
  async function renderMore() {
    if (st.more === "alerts") return renderAlerts();
    if (st.more === "events") return renderEvents();
    if (st.more === "family") return renderFamily();
    if (st.more === "settings") return renderSettings();
    if (st.more === "pin") return renderPin();
    if (st.more === "where") return renderWhere();
    if (st.more === "weather") return renderWeather();
    if (st.more === "widget") return renderWidget();
    if (!st.me.id) { const d = await must("dashboard"); st.me = d.me; st.settings = d.settings; }
    const item = (p, icon, l, sub = "") => `<button class="mitem" data-act="goMore" data-p="${p}">${icon}<span>${l}${sub ? `<small>${sub}</small>` : ""}</span>${ICON.right}</button>`;
    shell(`<div class="head"><div><h1>Ще</h1><small>${esc(st.me.name)}${isAdmin() ? " · адміністратор" : ""}</small></div></div>
      <section class="panel menu">
        ${item("events", ICON.cal, "Події", "нагадування, «коли дадуть світло»")}
        <a class="mitem" href="https://map.ukrainealarm.com" target="_blank" rel="noopener">${ICON.siren}<span>Рух дронів і ракет<small>офіційна карта «Повітряної тривоги»</small></span>${ICON.right}</a>
        ${item("where", ICON.pin, "Де сімʼя", "геолокація, якою поділились")}
        <button class="mitem" data-act="goMore" data-p="widget"><span class="mic">📱</span><span>Віджет на телефон<small>світло, АКБ і тривога на головному екрані</small></span>${ICON.right}</button>
        <button class="mitem" data-act="goMore" data-p="weather"><span class="mic">🌤</span><span>Погода й повітря<small>прогноз на 7 днів, якість повітря</small></span>${ICON.right}</button>
        ${item("family", ICON.users, "Сімʼя і Telegram", "запросити, мій Telegram, група")}
        ${isAdmin() ? item("settings", ICON.gear, "Налаштування", "інвертор, тариф, тривоги") : ""}
        ${item("pin", ICON.key, "Мій вхід", "номер телефону й пароль")}
        ${DEMO ? "" : `<button class="mitem" data-act="logout">${ICON.out}<span>Вийти на цьому пристрої</span></button>`}
      </section>`);
  }

  const BTN_DRONES = `<a class="btn lamp" href="https://map.ukrainealarm.com" target="_blank" rel="noopener" style="display:flex;justify-content:center;margin:0 0 12px">🛰 Рух дронів і ракет — офіційна карта</a>`;
  async function renderAlerts() {
    shell(`<div class="head">${st.tab === "more" ? back("goMenu") : ""}<h1 class="grow">Тривоги</h1></div><div class="empty">Завантаження…</div>`);
    const j = await must("dashboard");
    const al = j.alerts;
    if (!al || !al.has_token) {
      shell(`<div class="head">${st.tab === "more" ? back("goMenu") : ""}<h1 class="grow">Тривоги</h1></div>
        ${BTN_DRONES}
        <p class="note" style="margin:-6px 4px 12px">Працює без жодних токенів. Орієнтовний рух шахедів і крилатих ракет із затримкою; балістики там немає — орієнтуйтесь на сирену.</p>
        <section class="panel"><h2>Сповіщення про тривоги в групу</h2>
          <p style="margin:0 0 12px">Дані беруться з alerts.in.ua. Для них потрібен безкоштовний ключ доступу (токен), який видають за запитом.</p>
          <p style="margin:0 0 12px">1. Заповніть форму на <a href="https://alerts.in.ua/api-request" target="_blank" rel="noopener">alerts.in.ua/api-request</a>: «особистий застосунок для дому, опитування раз на хвилину».<br>2. Коли прийде токен, вставте його в Налаштуваннях.</p>
          ${isAdmin() ? '<button class="btn lamp" data-act="goMore" data-p="settings">Відкрити налаштування</button>' : ""}
        </section>`);
      return;
    }
    const sx = al.state.length === 27 ? al.state : "N".repeat(27);
    const m = window.UA_MAP;
    const cls = (i) => (i === 0 ? ([sx[0], sx[18]].find(isRaid) || (sx[0] === "P" || sx[18] === "P" ? "P" : "N")) : sx[i]); // Севастополь — разом із Кримом
    const active = REGIONS.map((n, i) => ({ n, c: sx[i] })).filter((x) => isRaid(x.c) || x.c === "P");
    const updated = al.at ? Math.round((j.now - al.at) / 60000) : null;
    shell(`<div class="head">${st.tab === "more" ? back("goMenu") : ""}<div class="grow"><h1>Тривоги</h1><small>${updated == null ? "" : updated <= 1 ? "оновлено щойно" : `оновлено ${updated} хв тому`}</small></div></div>
      ${raidBanner(al, j.now).replace(/data-tab="alerts"/, "")}
      ${al.zones ? `<section class="panel"><h2 class="row"><span>${ICON.pin}Де ми зараз</span><button class="link" data-act="zoneRefresh">оновити моє місце</button></h2>
        <ul class="zlist">${al.zones.family.map((f) => `<li><span class="av ${f.status && f.status.active ? "alarm" : f.status ? "calm" : ""}">${esc(f.name.slice(0, 1).toUpperCase())}</span>
          <span class="nm">${esc(f.name)}${f.me ? " (ви)" : ""}<small>${f.place ? `📍 ${esc(f.place)} · ${f.src === "telegram" ? "Telegram" : "додаток"}, ${agoT(f.at)}` : "місце невідоме"}</small>${f.status && f.status.active ? `<small class="al">${esc(f.status.kinds[0] || "Тривога")}${f.status.threat_names.length ? ` · ${esc(f.status.threat_names.join(", "))}` : ""}</small>` : ""}</span>
          <span class="pill ${f.status ? (f.status.active ? "on" : "off") : ""}">${f.status ? (f.status.active ? "тривога" : "тихо") : "—"}</span></li>`).join("")}</ul>
        <p class="note">Місце оновлюється само, коли відкриваєте «Світлицю» або ділитесь живою геопозицією з ботом. Сповіщення про тривогу там, де хтось із вас, приходять у сімейну групу.</p></section>` : ""}
      ${BTN_DRONES}
      <p class="note" style="margin:-6px 4px 12px">Карта «Повітряної тривоги» (Міноборони, Мінцифри, Повітряні сили): орієнтовний рух шахедів і крилатих ракет, із затримкою. Балістики там немає — орієнтуйтесь на сирену.</p>
      <section class="panel" style="padding:10px">
        <svg class="map" viewBox="${m.viewBox}" role="img" aria-label="Карта тривог: ${active.filter((x) => isRaid(x.c)).length} областей у тривозі">
          ${m.paths.map((p) => `<path d="${p.d}" class="${cls(p.i)} ${p.i === al.region || (al.region === 18 && p.i === 0) ? "me" : ""}"><title>${esc(m.names[p.i])}</title></path>`).join("")}
        </svg>
        <div class="legend" style="margin:6px 4px 0"><span><i style="background:var(--raid)"></i>тривога</span><span><i style="background:var(--raid-y)"></i>жовтий рівень</span><span><i style="background:var(--raid-p)"></i>частина області</span></div>
      </section>
      <section class="panel"><h2>${active.length ? `Тривога зараз (${active.filter((x) => isRaid(x.c)).length})` : "По всій Україні тривоги немає"}</h2>
        ${active.length ? `<div class="chips">${active.map((x) => `<span class="chip ${x.c}">${esc(x.n)}${x.c === "P" ? " · частково" : ""}</span>`).join("")}</div>` : ""}
        ${al.error ? `<p class="err" style="margin-top:10px">${esc(al.error)}</p>` : ""}
      </section>
      <p class="credit">Дані: ${al.src === "siren" ? '«Повітряна тривога» (через siren.pp.ua). Типи загроз — після підключення токена alerts.in.ua' : '<a href="https://alerts.in.ua" target="_blank" rel="noopener">alerts.in.ua</a>'} · Карта: @svg-maps/ukraine, CC BY 4.0</p>`);
  }

  async function renderFamily() {
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Сімʼя</h1></div><div class="empty">Завантаження…</div>`);
    const j = await must("members"); st.me = j.me;
    const d = await must("dashboard"); const s = (st.settings = d.settings);
    const mine = j.members.find((m) => m.id === st.me.id) || {};
    const fmtPh = (p) => (p ? esc(p.replace(/^\+380(\d{2})(\d{3})(\d{2})(\d{2})$/, "+380 $1 $2 $3 $4")) : "номер не вказано");
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Сімʼя</h1></div>
      <section class="panel"><h2>Хто має доступ</h2>
        <ul class="mlist">${j.members.map((m) => `<li><span class="av">${esc(m.name.slice(0, 1).toUpperCase())}</span><span class="nm">${esc(m.name)}${m.id === st.me.id ? " (ви)" : ""}<small>${m.role === "admin" ? "адміністратор" : "член сімʼї"} · ${fmtPh(m.phone)} · ${m.has_tg ? "Telegram ✓" : "Telegram —"}${m.has_pass ? "" : " · ще не задав пароль"}</small></span>${isAdmin() && m.id !== st.me.id ? `<span class="mact"><button class="link" data-act="memberReset" data-id="${m.id}" data-n="${esc(m.name)}">новий пароль</button><button class="link danger" data-act="memberRemove" data-id="${m.id}" data-n="${esc(m.name)}">прибрати</button></span>` : ""}</li>`).join("")}</ul>
        <div id="rst"></div>
        ${isAdmin() ? `<form id="inv-f" style="margin-top:14px"><label class="field"><span>Запросити на номер</span><input id="inv-ph" type="tel" inputmode="tel" autocomplete="off" placeholder="067 123 45 67" required></label><button class="btn">Створити запрошення</button></form><div id="inv"></div>
          ${j.invites.filter((i) => i.kind === "join").length ? `<p class="note" style="margin:10px 0 0">Очікують: ${j.invites.filter((i) => i.kind === "join").map((i) => fmtPh(i.phone)).join(", ")}</p>` : ""}` : ""}
      </section>
      <section class="panel"><h2>Мій Telegram</h2>
        ${mine.has_tg
          ? `<p class="ok" style="margin:0 0 12px">Підтверджено за номером ${fmtPh(mine.phone)}. Бот відповідає вам в особистих, можна бронювати зарядку ЖК.</p><button class="btn light" data-act="tgUnlink">Відвʼязати Telegram</button>`
          : `<p class="note" style="margin:0 0 12px">Бот пускає лише своїх: відкрийте його і натисніть <b>«📱 Поділитися номером»</b>. Номер вашого Telegram має бути <b>${fmtPh(mine.phone)}</b> — як у «Мій вхід».</p><button class="btn lamp" data-act="tgMe">${ICON.tg} Відкрити бота</button>`}
      </section>
      <section class="panel"><h2>Сімейна група в Telegram</h2>
        <p class="note" style="margin:0 0 12px">${s.tg_linked ? "Підключено. У групу приходять: світло зникло/повернулось, тривоги, нагадування про події, зміни у списку покупок." : "Бот надсилатиме в групу: світло зникло/повернулось, тривоги, нагадування про події, зміни у списку покупок."}</p>
        <div class="howto"><b>У групі можна:</b><br><code>/list</code> — список покупок з кнопками «куплено»<br><code>/buy молоко, хліб</code> — додати<br><code>/events</code> — найближчі події<br><code>/light пральку</code> — нагадати, коли дадуть світло<br>А в особистих повідомленнях боту (після підтвердження номера) — просто писати, що купити.</div>
        ${isAdmin() ? `<button class="btn light" data-act="tg" style="margin-top:12px">${s.tg_linked ? "Підключити іншу групу" : "Додати бота в групу"}</button><p class="note">Групу може підключити лише адміністратор, який уже підтвердив свій номер у боті.</p>` : ""}
      </section>`);
    const f = $("#inv-f"); if (f) f.onsubmit = (e) => { e.preventDefault(); H.invite(); };
  }


  const agoT = (iso) => { if (!iso) return ""; const m = Math.round((Date.now() - Date.parse(iso)) / 60000); return m < 1 ? "щойно" : m < 60 ? `${m} хв тому` : m < 1440 ? `${Math.round(m / 60)} год тому` : `${Math.round(m / 1440)} дн тому`; };
  // ───── Де сімʼя ─────
  const ago = (ms) => { const m = Math.round((Date.now() - ms) / 60000); return m < 1 ? "щойно" : m < 60 ? `${m} хв тому` : m < 1440 ? `${Math.round(m / 60)} год тому` : `${Math.round(m / 1440)} дн тому`; };
  let leaflet = null;
  function loadLeaflet() {
    if (window.L) return Promise.resolve(window.L);
    if (leaflet) return leaflet;
    leaflet = new Promise((ok, no) => {
      const css = document.createElement("link"); css.rel = "stylesheet"; css.href = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css"; document.head.appendChild(css);
      const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js";
      s.onload = () => ok(window.L); s.onerror = () => { leaflet = null; no(); }; document.head.appendChild(s);
    });
    return leaflet;
  }
  async function renderWhere() {
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Де сімʼя</h1><button class="ghost" data-act="goMore" data-p="where">Оновити</button></div><div id="wbox"><div class="empty">Завантаження…</div></div>`);
    if (!st.me.id) { const d = await must("dashboard"); st.me = d.me; }
    drawWhere(await must("locations"));
  }
  function drawWhere(j) {
    const box = $("#wbox"); if (!box) return;
    const now = Date.now();
    const L = j.locations.map((l) => {
      const upd = Date.parse(l.updated_at), live = l.live_until && Date.parse(l.live_until) > now && now - upd < 20 * 60000;
      return { ...l, upd, live, mine: l.who === "m:" + st.me.id };
    });
    const mine = L.find((l) => l.mine);
    box.innerHTML = `
      ${L.length ? '<div class="panel" style="padding:0;overflow:hidden"><div id="lmap" class="lmap" role="img" aria-label="Карта з членами сімʼї"></div></div>' : ""}
      <section class="panel">
        ${L.length ? `<ul class="mlist">${L.map((l) => `<li><span class="av ${l.live ? "live" : ""}">${esc(l.name.slice(0, 1).toUpperCase())}</span>
          <span class="nm">${esc(l.name)}${l.mine ? " (ви)" : ""}<small>${l.live ? '<b class="livetag">наживо</b> · ' : ""}${ago(l.upd)}${l.accuracy ? ` · ±${Math.round(l.accuracy)} м` : ""}${l.source === "telegram" ? " · Telegram" : ""}</small></span>
          <a class="link" href="https://www.google.com/maps/search/?api=1&query=${l.lat},${l.lon}" target="_blank" rel="noopener">на карті</a></li>`).join("")}</ul>`
        : '<div class="empty" style="padding:12px"><b>Поки ніхто не ділився</b>Кожен вирішує сам, чи показувати своє місце.</div>'}
      </section>
      <section class="panel"><h2>Моє місце</h2>
        <div class="row2"><button class="btn lamp" data-act="locShare">${ICON.pin} Показати, де я зараз</button>${mine ? '<button class="btn light" data-act="locStop">Прибрати</button>' : ""}</div>
        <p class="note">Після першого разу місце оновлюється саме, коли відкриваєте «Світлицю» (не частіше ніж раз на 10 хв). У фоні додаток не стежить.</p>
        <div class="howto" style="margin-top:12px"><b>Щоб сімʼя бачила вас постійно</b><br>Відкрийте бота в Telegram → 📎 → Геопозиція → «Транслювати геопозицію» → «Поки не вимкну». Зупинити — там само або командою <code>/stoploc</code>. Зберігається лише остання точка, без історії.</div>
      </section>`;
    if (!L.length) return;
    loadLeaflet().then((Lf) => {
      const el = $("#lmap"); if (!el) return;
      const map = Lf.map(el, { zoomControl: true, attributionControl: true });
      Lf.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "© OpenStreetMap" }).addTo(map);
      const pts = L.map((l) => {
        const icon = Lf.divIcon({ className: "", html: `<span class="mpin ${l.live ? "live" : ""}">${esc(l.name.slice(0, 1).toUpperCase())}</span>`, iconSize: [34, 34], iconAnchor: [17, 17] });
        Lf.marker([l.lat, l.lon], { icon, title: l.name }).addTo(map).bindTooltip(`${esc(l.name)} · ${ago(l.upd)}`);
        return [l.lat, l.lon];
      });
      if (pts.length === 1) map.setView(pts[0], 14); else map.fitBounds(pts, { padding: [36, 36], maxZoom: 15 });
    }).catch(() => { const el = $("#lmap"); if (el) el.outerHTML = '<p class="note" style="padding:12px 16px;margin:0">Карта не завантажилась — відкрийте точку через «на карті».</p>'; });
  }

  async function renderPin() {
    const d = await must("dashboard"); st.me = d.me;
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Мій вхід</h1></div>
      <section class="panel">
        <form id="acc" autocomplete="on">
          <label class="field"><span>Номер телефону</span><input id="a-phone" type="tel" inputmode="tel" autocomplete="tel" value="${esc(st.me.phone || "")}"></label>
          <label class="field"><span>Поточний пароль</span><input id="a-cur" type="password" autocomplete="current-password" required></label>
          <label class="field"><span>Новий пароль <small class="muted">(порожньо — не змінювати)</small></span><input id="a-new" type="password" autocomplete="new-password"></label>
          <label class="field"><span>Новий пароль ще раз</span><input id="a-new2" type="password" autocomplete="new-password"></label>
          <button class="btn">Зберегти</button>
        </form>
        <p class="note">Пароль — щонайменше 8 символів, літери й цифри. Після зміни на інших пристроях треба увійти знову. Якщо зміните номер, Telegram доведеться підтвердити заново.</p>
      </section>`);
    $("#acc").onsubmit = async (e) => {
      e.preventDefault();
      const pw = $("#a-new").value;
      if (pw && pw !== $("#a-new2").value) return toast("Нові паролі не збігаються");
      const j = await call("credentials_save", { phone: $("#a-phone").value, current: $("#a-cur").value, password: pw || undefined });
      if (!j.ok) return toast(j.error);
      token = j.token; try { localStorage.setItem("energy-token", token); } catch {}
      toast(j.tg_unlinked ? "Збережено. Підтвердіть новий номер у боті" : "Збережено"); H.goMenu();
    };
  }

  async function renderSettings() {
    const j = await must("dashboard"); const s = (st.settings = j.settings); st.me = j.me;
    const dt = await callDtek("dtek"); st.groups = dt.groups || []; Object.assign(s, dt.settings || {});
    shell(`<div class="head">${back("goMenu")}<h1 class="grow">Налаштування</h1></div>
      <section class="panel"><h2>SmartESS</h2>
        ${s.dess_sn ? `<p class="ok" style="margin:0 0 10px">Підключено: ${esc(s.dess_alias)} · ${esc(s.dess_sn)}</p>` : '<p class="note" style="margin:0 0 10px">Той самий логін і пароль, що в програмі SmartESS.</p>'}
        <label class="field"><span>Логін (email або імʼя)</span><input id="d-user" autocomplete="username" value="${esc(s.dess_user)}"></label>
        <label class="field"><span>Пароль${s.has_pass ? " (залиште порожнім, щоб не змінювати)" : ""}</span><input id="d-pass" type="password" autocomplete="current-password"></label>
        <button class="btn lamp" data-act="connect">${s.dess_sn ? "Перепідключити" : "Підключити інвертор"}</button>
        <div id="d-res" class="note" role="status"></div>
      </section>
      <section class="panel"><h2>Тариф</h2>
        <label class="field"><span>Ціна, грн за кВт·год</span><input id="t-day" type="number" inputmode="decimal" step="0.01" value="${s.tariff_day}"></label>
        <label class="check"><input type="checkbox" id="t-zones" ${s.tariff_zones ? "checked" : ""}> Двозонний лічильник (день/ніч)</label>
        <div id="zones" ${s.tariff_zones ? "" : "hidden"}>
          <label class="field"><span>Нічна ціна, грн</span><input id="t-night" type="number" inputmode="decimal" step="0.01" value="${s.tariff_night}"></label>
          <div class="row2"><label class="field"><span>Ніч з</span><input id="t-from" type="time" value="${s.night_from}"></label><label class="field"><span>до</span><input id="t-to" type="time" value="${s.night_to}"></label></div>
        </div>
        <p class="note" style="margin:0 0 12px">Для населення зараз 4,32 грн (діє до 30.04.2027).</p>
        <h2>Акумулятор</h2>
        <div class="row2">
          <label class="field"><span>Ємність, кВт·год</span><input id="b-kwh" type="number" inputmode="decimal" step="0.01" value="${s.batt_kwh ?? ""}" placeholder="напр. 5.12"></label>
          <label class="field"><span>Попереджати при, %</span><input id="b-low" type="number" inputmode="numeric" value="${s.low_soc}"></label>
        </div>
        <p class="note" style="margin:0 0 12px">Ємність потрібна, щоб показувати, на скільки ще вистачить АКБ.</p>
        <button class="btn" data-act="saveSettings">Зберегти</button>
      </section>
      <section class="panel"><h2>Графік ДТЕК</h2>
        <label class="field"><span>Регіон</span><select id="g-area">${Object.entries(s.areas || { kyiv: "Київ", "kyiv-region": "Київська область" }).map(([k, l]) => `<option value="${k}" ${k === (s.dtek_area || "kyiv") ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>
        <label class="field"><span>Моя черга (підчерга)</span><select id="g-group"><option value="">— не вибрано —</option>${(st.groups || []).map((g) => `<option ${g === s.dtek_group ? "selected" : ""}>${g}</option>`).join("")}${s.dtek_group && !(st.groups || []).includes(s.dtek_group) ? `<option selected>${esc(s.dtek_group)}</option>` : ""}</select></label>
        <p class="note" style="margin:-4px 0 12px">Не знаєте свою чергу? Введіть адресу на <a href="https://www.dtek-kem.com.ua/ua/shutdowns" target="_blank" rel="noopener">dtek-kem.com.ua</a> (Київ) або <a href="https://www.dtek-krem.com.ua/ua/shutdowns" target="_blank" rel="noopener">dtek-krem.com.ua</a> (Київська область).</p>
        <label class="check"><input type="checkbox" id="g-notify" ${s.dtek_notify ? "checked" : ""}> Telegram: попередження перед відключенням, новий графік і зміни</label>
        <div class="row2">
          <label class="field"><span>Попереджати за</span><select id="g-before">${[[15, "15 хв"], [30, "30 хв"], [60, "1 год"], [120, "2 год"]].map(([v, l]) => `<option value="${v}" ${v === s.dtek_before ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <label class="field"><span>Резерв АКБ, %</span><input id="g-reserve" type="number" inputmode="numeric" value="${s.batt_reserve}"></label>
        </div>
        <p class="note" style="margin:0 0 12px">Резерв — нижче якого інвертор не розряджає АКБ. Прогноз рахує заряд понад нього.</p>
        <button class="btn" data-act="saveDtek">Зберегти</button>
      </section>
      <section class="panel"><h2>Тривоги</h2>
        <label class="field"><span>Токен alerts.in.ua${s.has_alerts_token ? " (збережено — вставте новий, щоб замінити)" : ""}</span><input id="a-token" type="password" autocomplete="off" placeholder="${s.has_alerts_token ? "••••••••" : "вставте токен"}"></label>
        <label class="field"><span>Мій регіон</span><select id="a-region">${REGIONS.map((n, i) => `<option value="${i}" ${i === s.alerts_region ? "selected" : ""}>${esc(n)}</option>`).join("")}</select></label>
        <label class="check"><input type="checkbox" id="a-notify" ${s.alerts_notify ? "checked" : ""}> Сповіщати в Telegram про тривогу й відбій</label>
        ${s.has_alerts_token ? "" : '<p class="note" style="margin:0 0 12px">Токен видають за запитом на <a href="https://alerts.in.ua/api-request" target="_blank" rel="noopener">alerts.in.ua/api-request</a>.</p>'}
        <button class="btn" data-act="saveAlerts">Зберегти</button>
      </section>
      <section class="panel"><h2>Дані з інвертора</h2><div id="pts"><button class="btn light" data-act="points">Показати всі показники</button></div></section>`);
    $("#t-zones").addEventListener("change", (e) => { $("#zones").hidden = !e.target.checked; });
    $("#g-area").addEventListener("change", async (e) => {
      const g = $("#g-group"); g.disabled = true;
      const j = await callDtek("dtek_save", { settings: { dtek_area: e.target.value, dtek_group: "" } });
      if (!j.ok) { toast(j.error); g.disabled = false; return; }
      const d = await callDtek("dtek"); st.groups = d.groups || [];
      g.innerHTML = '<option value="">— не вибрано —</option>' + st.groups.map((x) => `<option>${x}</option>`).join(""); g.disabled = false;
      toast("Тепер виберіть свою чергу");
    });
  }

  const H = {
    async refresh() { await call("poll_now"); toast("Дані оновлено"); render(); },
    lightView(d) { st.light = d.v; render(); },
    period(d) { st.period = d.p; render(); },
    shift(d) { if (st.period === "week") st.anchor = addDays(st.anchor, 7 * +d.n); else { const x = D(st.anchor.slice(0, 8) + "01"); x.setMonth(x.getMonth() + +d.n); st.anchor = iso(x); } render(); },
    mshift(d) { const x = D(st.month + "-01"); x.setMonth(x.getMonth() + +d.n); st.month = iso(x).slice(0, 7); render(); },
    goMore(d) { st.tab = "more"; st.more = d.p; render(); window.scrollTo(0, 0); },
    goMenu() { st.more = "menu"; render(); window.scrollTo(0, 0); },
    async zoneRefresh(_d, el) { el.textContent = "визначаю…"; const j = await autoLocate(true); if (j && j.ok) { toast("Місце оновлено"); render(); } else el.textContent = "оновити моє місце"; },
    // покупки
    async shopToggle(d) { const j = await call("shop_toggle", { id: +d.id }); if (!j.ok) return toast(j.error); drawShop(j); },
    async shopDel(d) { const j = await call("shop_delete", { id: +d.id }); if (!j.ok) return toast(j.error); drawShop(j); },
    async shopClear() { const j = await call("shop_clear"); if (!j.ok) return toast(j.error); drawShop(j); },
    async shopQuick(d) { const j = await call("shop_add", { text: d.n }); if (!j.ok) return toast(j.error); drawShop(j); },
    // події
    async newEvent() { if (!st.ev) st.ev = await must("events_list"); eventSheet(null); },
    async openEvent(d) { if (!st.ev) st.ev = await must("events_list"); const e = st.ev.events.find((x) => x.id === +d.id); if (e) eventSheet(e); },
    async powerDone(d) { const j = await call("power_done", { id: +d.id }); if (!j.ok) return toast(j.error); drawEvents(j); },
    // витрати
    shopView(d) { st.shopView = d.v; render(); },
    spShift(d) { const x = D(st.spendMonth + "-01"); x.setMonth(x.getMonth() + +d.n); st.spendMonth = iso(x).slice(0, 7); renderSpend(); },
    spCat(d) { st.spendCat = d.c || null; drawSpend(st.spend); },
    txOpen(d) { const t = st.spend.txns.find((x) => x.id === d.id); if (t) txSheet(t); },
    cashAdd() { cashSheet(); },
    async wMake() { const j = await callWidget("widget_key"); if (!j.ok) return toast(j.error || "Помилка"); toast("Посилання створено"); renderWidget(j); },
    async wOff(_d, el) { if (el.dataset.sure !== "1") { el.dataset.sure = "1"; el.textContent = "Точно вимкнути?"; return; } await callWidget("widget_off"); toast("Віджет вимкнено"); renderWidget(); },
    async wCopy(d) { const t = d.v === "url" ? st.wUrl : `$wg("${st.wUrl || "ПОСИЛАННЯ"}", json, ".${d.v}")$`; try { await navigator.clipboard.writeText(t); toast("Скопійовано"); } catch { toast("Не вдалося скопіювати — виділіть вручну"); } },
    wxPlace(d) { st.wx = d.v; renderWeather(); },
    wxDefault() { try { localStorage.setItem("svit-wx-place", st.wx); } catch {} toast("Буде на головному екрані"); renderWeather(); },
    mTab(d) { st.mTab = d.v; drawSpend(st.spend); window.scrollTo(0, 0); },
    budNew() { budSheet(null); },
    budOpen(d) { budSheet(d.c); },
    planNew(d) { planSheet(null, d.k); },
    planOpen(d) { const p = st.spend.planner.plans.find((x) => x.id === +d.id); if (p) planSheet(p); },
    goalNew() { goalSheet(null); },
    goalOpen(d) { const g = st.spend.planner.goals.find((x) => x.id === +d.id); if (g) goalSheet(g); },
    accNew() { accSheet(null); },
    accOpen(d) { const a = st.spend.planner.accounts.find((x) => x.cid === +d.id); if (a) accSheet(a); },
    async monoConnect(_d, el) {
      const tok = $("#mono-tok").value.trim(); if (!tok) return toast("Вставте токен");
      el.disabled = true; el.textContent = "Перевіряю…";
      const r = await callMoney("mono_connect", { token: tok });
      el.disabled = false; el.textContent = "Підключити";
      if (!r.ok) return toast(r.error);
      toast(`Підключено! Історію за 2 місяці підтягну за ≈ ${r.minutes} хв`); drawSpend(r);
    },
    async monoOff(d, el) {
      if (el.dataset.sure !== "1") { el.dataset.sure = "1"; el.textContent = "точно відключити?"; return; }
      const r = await callMoney("mono_disconnect", { link_id: +d.id, month: st.spendMonth }); if (!r.ok) return toast(r.error); toast("Monobank відключено"); drawSpend(r);
    },
    // зарядка ЖК
    goSpend() { st.tab = "shop"; st.shopView = "spend"; render(); window.scrollTo(0, 0); },
    goCharge() { st.tab = "light"; st.light = "charge"; render(); window.scrollTo(0, 0); },
    async tgMe() { const j = await must("tg_me_link"); const a = document.createElement("a"); a.href = j.url; a.target = "_blank"; a.rel = "noopener"; a.click(); toast("У боті натисніть «📱 Поділитися номером»"); },
    async tgUnlink(_d, el) { if (el.dataset.sure !== "1") { el.dataset.sure = "1"; el.textContent = "Точно відвʼязати?"; return; } await must("tg_unlink"); toast("Telegram відвʼязано"); render(); },
    chPick(d) { CH[d.k] = +d.v; drawCharge(st.charge); },
    async chRegister() { const j = await call("charging", { op: "register" }); if (!j.ok) return toast(j.error); drawCharge(j); toast("Готово"); },
    async chBook(_d, el) {
      el.disabled = true;
      const j = await call("charging", { op: "book", kw: CH.kw, dur_min: CH.dur, start_min: CH.start });
      el.disabled = false;
      if (!j.ok) return toast(j.error);
      if (j.result.booked) { toast("Заброньовано"); return drawCharge(j); }
      const r = j.result, alt = r.alt ? Math.round((r.alt - j.status.now) / 60) : null;
      $("#ch-res").innerHTML = `<p class="err" style="margin:12px 0 8px">${esc(r.reason)}</p>
        ${r.need_queue || r.can_queue ? '<button class="btn" data-act="chQueue">Стати в чергу</button>' : ""}
        ${alt != null ? `<button class="btn light" style="margin-top:8px" data-act="chAlt" data-m="${alt}">Забронювати з ${hm(r.alt * 1000)}</button>` : ""}`;
    },
    async chAlt(d) { CH.start = +d.m; const j = await call("charging", { op: "book", kw: CH.kw, dur_min: CH.dur, start_min: +d.m }); CH.start = 0; if (!j.ok) return toast(j.error); if (j.result.booked) toast("Заброньовано"); else toast(j.result.reason); drawCharge(j); },
    async chQueue() { const j = await call("charging", { op: "queue_join", kw: CH.kw, dur_min: CH.dur }); if (!j.ok) return toast(j.error); toast(j.result.status === "offered" ? "Місце вже звільнилось — підтвердіть" : `Ви ${j.result.pos}-і в черзі`); drawCharge(j); },
    async chDone(d) { const j = await call("charging", { op: "done", id: +d.id }); if (!j.ok) return toast(j.error); toast(j.result.closed === "cancelled" ? "Бронь скасовано" : "Дякуємо! Розетка вільна для сусідів"); drawCharge(j); },
    async chExt(d) { const j = await call("charging", { op: "extend", id: +d.id, min: +d.m }); if (!j.ok) return toast(j.error); toast("Продовжено"); drawCharge(j); },
    async chLeave(d) { const j = await call("charging", { op: "q_leave", id: +d.id }); if (!j.ok) return toast(j.error); toast("Ви вийшли з черги"); drawCharge(j); },
    async chTake(d) { const j = await call("charging", { op: "q_take", id: +d.id }); if (!j.ok) return toast(j.error); toast("Заброньовано — можна підключати"); drawCharge(j); },
    // сімʼя
    async invite() {
      const ph = $("#inv-ph").value;
      const j = await must("invite_create", { phone: ph });
      const url = `${location.origin}${location.pathname}?invite=${j.code}`;
      $("#inv").innerHTML = `<div class="invite"><p class="note" style="margin:0 0 8px">Надішліть посилання власнику номера ${esc(ph)}. Зареєструватись за ним можна лише з цим номером. Діє 3 дні, одноразове.</p><input readonly value="${esc(url)}" aria-label="Посилання-запрошення"><div class="row2" style="margin-top:8px"><button class="btn light" data-act="copyInvite">Копіювати</button><button class="btn lamp" data-act="shareInvite">Надіслати</button></div></div>`;
      H._inv = url;
    },
    async copyInvite() { try { await navigator.clipboard.writeText(H._inv); toast("Скопійовано"); } catch { const i = $(".invite input"); i.select(); toast("Виділено — скопіюйте"); } },
    async shareInvite() { if (navigator.share) { try { await navigator.share({ title: "Світлиця", text: "Приєднуйся до нашої сімейної «Світлиці»:", url: H._inv }); } catch {} } else H.copyInvite(); },
    async memberReset(d, el) {
      if (el.dataset.sure !== "1") { el.dataset.sure = "1"; el.textContent = `скинути пароль ${d.n}?`; return; }
      const j = await must("member_reset", { id: +d.id });
      const url = `${location.origin}${location.pathname}#reset=${j.code}`; H._inv = url;
      $("#rst").innerHTML = `<div class="invite"><p class="note" style="margin:0 0 8px">Посилання для нового пароля (${esc(d.n)}). Діє 24 год, одноразове. Надішліть особисто.</p><input readonly value="${esc(url)}" aria-label="Посилання для нового пароля"><div class="row2" style="margin-top:8px"><button class="btn light" data-act="copyInvite">Копіювати</button><button class="btn lamp" data-act="shareInvite">Надіслати</button></div></div>`;
    },
    async memberRemove(d, el) {
      if (el.dataset.sure !== "1") { el.dataset.sure = "1"; el.textContent = `прибрати ${d.n}?`; return; }
      await must("member_remove", { id: +d.id }); toast("Доступ закрито"); render();
    },
    locShare(_d, el) {
      if (!navigator.geolocation) return toast("Телефон не дає геолокацію");
      el.disabled = true; el.textContent = "Визначаю…";
      navigator.geolocation.getCurrentPosition(async (p) => {
        const j = await call("loc_share", { lat: p.coords.latitude, lon: p.coords.longitude, accuracy: p.coords.accuracy });
        if (!j.ok) return toast(j.error); try { localStorage.setItem("svit-autoloc", "1"); localStorage.setItem("svit-autoloc-at", String(Date.now())); } catch {} toast("Сімʼя бачить, де ви"); drawWhere(j);
      }, (e) => { el.disabled = false; el.textContent = "Показати, де я зараз"; toast(e.code === 1 ? "Дозвольте доступ до геолокації в браузері" : "Не вдалося визначити місце"); }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
    },
    async locStop() { const j = await call("loc_stop"); if (!j.ok) return toast(j.error); toast("Вашу точку прибрано"); drawWhere(j); },
    // налаштування
    async connect() {
      const res = $("#d-res"); res.className = "note"; res.textContent = "Підключаюсь до SmartESS…";
      const j = await call("dess_connect", { user: $("#d-user").value, pass: $("#d-pass").value });
      if (!j.ok) { res.className = "err"; res.textContent = j.error; return; }
      res.className = "ok"; res.textContent = `Готово: ${j.device} (${j.sn}). Перші дані вже записано.`;
      setTimeout(() => { st.tab = "home"; render(); }, 1200);
    },
    async saveSettings() {
      await must("settings_save", { settings: { tariff_day: $("#t-day").value, tariff_zones: $("#t-zones").checked, tariff_night: $("#t-night").value, night_from: $("#t-from").value, night_to: $("#t-to").value, batt_kwh: $("#b-kwh").value, low_soc: $("#b-low").value } });
      toast("Збережено");
    },
    async saveDtek() {
      const btn = document.querySelector('[data-act="saveDtek"]'); btn.disabled = true; btn.textContent = "Завантажую графік…";
      const j = await callDtek("dtek_save", { settings: { dtek_area: $("#g-area").value, dtek_group: $("#g-group").value, dtek_notify: $("#g-notify").checked, dtek_before: +$("#g-before").value, batt_reserve: $("#g-reserve").value } });
      btn.disabled = false; btn.textContent = "Зберегти";
      if (!j.ok) { toast(j.error); return; }
      Object.assign(st.settings, j.settings); toast("Збережено — графік на головному екрані");
    },
    async saveAlerts() {
      const btn = document.querySelector('[data-act="saveAlerts"]'); btn.disabled = true; btn.textContent = "Перевіряю…";
      const j = await call("settings_save", { settings: { alerts_token: $("#a-token").value.trim() || undefined, alerts_region: +$("#a-region").value, alerts_notify: $("#a-notify").checked } });
      btn.disabled = false; btn.textContent = "Зберегти";
      if (!j.ok) { toast(j.error); return; }
      st.settings = j.settings; $("#a-token").value = ""; toast("Збережено");
    },
    async tg() { const j = await must("tg_link"); const a = document.createElement("a"); a.href = j.url; a.target = "_blank"; a.rel = "noopener"; a.click(); },
    async points() { const j = await must("points"); $("#pts").innerHTML = j.points.length ? `<div class="points">${j.points.map(([t, v, u]) => `<span>${esc(t)}</span><span>${esc(v)} ${esc(u)}</span>`).join("")}</div>` : '<p class="note">Ще немає даних</p>'; },
    logout() { token = ""; try { localStorage.removeItem("energy-token"); } catch {} showLogin(); },
  };

  function render() {
    closeSheet();
    if (st.tab === "home") return renderHome();
    if (st.tab === "shop") return renderShop();
    if (st.tab === "events") { st.tab = "more"; st.more = "events"; return renderEvents(); }
    if (st.tab === "alerts") return renderAlerts();
    if (st.tab === "light") return st.light === "money" ? renderMoney() : st.light === "charge" ? renderCharge() : renderOutages();
    return renderMore();
  }

  // ───── Вхід: номер телефону й пароль; запрошення на номер; новий пароль за посиланням ─────
  const resetCode = () => { const m = location.hash.match(/reset=([\w-]+)/); return m ? m[1] : null; };
  const clearLinks = () => history.replaceState(null, "", location.pathname);
  const field = (id, label, type, ac, extra = "") => `<label class="field"><span>${label}</span><input id="${id}" type="${type}" ${type === "tel" ? 'inputmode="tel" placeholder="067 123 45 67"' : ""} autocomplete="${ac}" ${extra}></label>`;
  const PW_HINT = '<p class="note" style="margin:-4px 0 12px">Щонайменше 8 символів, літери й цифри.</p>';
  function loginScreen(html, onSubmit) {
    root.onclick = null;
    root.innerHTML = `<div class="login"><form id="lf" autocomplete="on">${html}<p class="err" id="lerr" role="alert" style="min-height:20px;margin:10px 0 0"></p></form></div>`;
    const f = $("#lf"), first = f.querySelector("input"); if (first) first.focus();
    const bk = $("#back-login"); if (bk) bk.onclick = () => showLogin();
    f.onsubmit = async (e) => {
      e.preventDefault(); const b = f.querySelector("button[type=submit],button:not([type])"); if (b) b.disabled = true; $("#lerr").textContent = "";
      try { await onSubmit((m) => { $("#lerr").textContent = m; }); } finally { if (b) b.disabled = false; }
    };
  }
  const pwPair = (err) => { const a = $("#pw1").value, b = $("#pw2").value; if (a !== b) { err("Паролі не збігаються"); return null; } return a; };
  function enter(tok) { token = tok; try { localStorage.setItem("energy-token", token); } catch {} clearLinks(); root.onclick = null; st.tab = "home"; st.me = {}; render(); }

  async function showLogin() {
    const invite = new URLSearchParams(location.search).get("invite"), reset = resetCode();
    if (invite || reset) {
      const c = await call("invite_check", { code: invite || reset });
      if (!c.valid) {
        root.innerHTML = `<div class="login"><h1>Посилання не діє</h1><p class="muted">Воно вже використане або минув термін. Попросіть нове.</p><button class="btn" id="to-login" style="margin-top:16px">До входу</button></div>`;
        $("#to-login").onclick = () => { clearLinks(); showLogin(); }; return;
      }
      if (c.kind === "reset") return loginScreen(`<h1>Новий пароль${c.name ? `, ${esc(c.name)}` : ""}</h1><p class="muted" style="margin:0 0 16px">${c.needs_phone ? "Вкажіть свій номер і придумайте пароль." : `Для номера ${esc(c.phone_hint || "")}.`}</p>
        ${c.needs_phone ? field("ph", "Номер телефону", "tel", "tel") : ""}${field("pw1", "Новий пароль", "password", "new-password")}${PW_HINT}${field("pw2", "Ще раз", "password", "new-password")}
        <button class="btn lamp">Зберегти й увійти</button>`, async (err) => {
        const pw = pwPair(err); if (!pw) return;
        const j = await call("reset", { code: reset || invite, password: pw, phone: c.needs_phone ? $("#ph").value : undefined });
        if (!j.ok) return err(j.error); enter(j.token);
      });
      return loginScreen(`<h1>Вас запросили до «Світлиці»</h1><p class="muted" style="margin:0 0 16px">Запрошення на номер ${esc(c.phone_hint || "")}.</p>
        ${field("nm", "Як вас підписувати", "text", "given-name", 'maxlength="30" placeholder="Напр.: Оля"')}${field("ph", "Ваш номер телефону", "tel", "tel")}
        ${field("pw1", "Придумайте пароль", "password", "new-password")}${PW_HINT}${field("pw2", "Пароль ще раз", "password", "new-password")}
        <button class="btn lamp">Приєднатися</button>`, async (err) => {
        const pw = pwPair(err); if (!pw) return;
        const j = await call("join", { code: invite, name: $("#nm").value, phone: $("#ph").value, password: pw });
        if (!j.ok) return err(j.error); enter(j.token);
      });
    }
    const s = await call("status");
    if (s.ok && s.needs_setup) return loginScreen(`<h1>Вітаємо у «Світлиці»</h1><p class="muted" style="margin:0 0 16px">Ви будете адміністратором сімʼї.</p>
      ${field("nm", "Ваше імʼя", "text", "given-name", 'maxlength="30"')}${field("ph", "Номер телефону", "tel", "tel")}
      ${field("pw1", "Придумайте пароль", "password", "new-password")}${PW_HINT}${field("pw2", "Пароль ще раз", "password", "new-password")}
      <button class="btn lamp">Створити</button>`, async (err) => {
      const pw = pwPair(err); if (!pw) return;
      const j = await call("setup", { name: $("#nm").value, phone: $("#ph").value, password: pw });
      if (!j.ok) return err(j.error); enter(j.token);
    });
    loginScreen(`<h1 class="brand">Світлиця</h1><p class="muted" style="margin:0 0 16px">Вхід для сімʼї</p>
      ${field("ph", "Номер телефону", "tel", "username")}${field("pw", "Пароль", "password", "current-password")}
      <button class="btn lamp">Увійти</button>
      <p style="margin:14px 0 0;text-align:center"><button type="button" class="link" id="forgot">Забули пароль?</button></p>`, async (err) => {
      const j = await call("login", { phone: $("#ph").value, password: $("#pw").value });
      if (!j.ok) { $("#pw").value = ""; return err(s.ok ? j.error : s.error || j.error); } enter(j.token);
    });
    $("#forgot").onclick = () => loginScreen(`<h1>Забули пароль?</h1><p class="muted" style="margin:0 0 16px">Якщо ваш номер підтверджено в боті «Світлиці», він надішле вам у Telegram посилання для нового пароля. Інакше попросіть адміністратора: Ще → Сімʼя → «новий пароль».</p>
      ${field("ph", "Номер телефону", "tel", "username")}<button class="btn lamp">Надіслати посилання</button>
      <p style="margin:14px 0 0;text-align:center"><button type="button" class="link" id="back-login">До входу</button></p>`, async (err) => {
      const j = await call("forgot", { phone: $("#ph").value });
      if (!j.ok) return err(j.error);
      $("#lerr").className = "ok"; $("#lerr").textContent = "Якщо номер є в сімʼї й підтверджений у боті — посилання вже в Telegram (діє 30 хв).";
    });
  }

  // Перехід зі старого PIN: один раз задати номер і пароль
  let credShown = false;
  function showCredentials(me) {
    if (credShown && document.querySelector("#lf")) return; credShown = true;
    loginScreen(`<h1>Новий вхід${me && me.name ? `, ${esc(me.name)}` : ""}</h1><p class="muted" style="margin:0 0 16px">Тепер «Світлиця» відкривається за номером телефону й паролем, а бот у Telegram — лише після підтвердження цього ж номера. Задайте їх один раз.</p>
      ${field("ph", "Ваш номер телефону", "tel", "username")}${field("pw1", "Придумайте пароль", "password", "new-password")}${PW_HINT}${field("pw2", "Пароль ще раз", "password", "new-password")}
      <button class="btn lamp">Зберегти</button>`, async (err) => {
      const pw = pwPair(err); if (!pw) return;
      const j = await call("credentials_save", { phone: $("#ph").value, password: pw });
      if (!j.ok) return err(j.error); credShown = false; enter(j.token);
    });
  }

  // автооновлення: головний і тривоги — щохвилини, покупки — кожні 6 с (бачите, що відмітив інший)
  const idle = () => document.visibilityState === "visible" && (DEMO || token) && !document.querySelector(".login") && !$("#sheet") && !document.querySelector("input:focus,select:focus");
  setInterval(() => { if ((st.tab === "home" || st.tab === "alerts" || (st.tab === "more" && st.more === "alerts")) && idle()) render().catch(() => {}); }, 60000);
  setInterval(async () => { if (st.tab === "light" && st.light === "charge" && idle() && st.charge?.linked) { const j = await call("charging"); if (j.ok) drawCharge(j); } }, 15000);
  setInterval(async () => {
    if (st.tab !== "shop" || !idle() || DEMO) return;
    const j = await call("shop_list"); if (!j.ok) return;
    const sig = (x) => JSON.stringify(x.items.map((i) => [i.id, i.bought_at]));
    if (!st.shop || sig(j) !== sig(st.shop)) drawShop(j);
  }, 6000);
  if ("serviceWorker" in navigator && location.protocol === "https:" && !DEMO) navigator.serviceWorker.register("sw.js").catch(() => {});
  const invited = new URLSearchParams(location.search).has("invite") || !!resetCode();
  if ((DEMO || token) && !invited) render().catch(() => {}); else showLogin();
})();
