// Адреса сервера.
window.ENERGY_API = "https://isvddzdqqxnwkcfvmtfy.supabase.co/functions/v1/energy";
