// Демо-сервер: правдоподібні дані інвертора за 3 тижні (графік відключень, АКБ, сонце)
(function () {
  const STEP = 5 * 60000, DAYS = 21, BATT_KWH = 5.12, TARIFF = 4.32;
  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const pad = (n) => String(n).padStart(2, "0");
  const dayOf = (ms) => { const d = new Date(ms); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
  const hmOf = (ms) => { const d = new Date(ms); return d.getHours() + d.getMinutes() / 60; };
  // тривоги: стан областей і історія для Києва
  let alertState = "N".repeat(27).split("");
  [4, 12, 21, 22, 19, 7].forEach((i) => (alertState[i] = "R")); alertState[3] = "P"; alertState[9] = "R"; alertState[10] = "R";
  alertState = alertState.join("");
  const alertsHist = [];
  const settings = { alerts_region: 9, alerts_notify: true, has_alerts_token: true, dess_user: "demo@example.com", has_pass: true, dess_alias: "PARADISE", dess_sn: "Q004712531246809AD05", tariff_day: 4.32, tariff_night: 2.16, tariff_zones: false, night_from: "23:00", night_to: "07:00", low_soc: 25, batt_kwh: BATT_KWH, tg_linked: false, bot_username: "", last_error: "", last_ok: Date.now(), dtek_group: "3.1", dtek_notify: true, dtek_before: 30, batt_reserve: 10 };

  // графік: на кожен день 0–3 вікна відключень по 2–4 години
  const now = Date.now();
  const start = new Date(now - DAYS * 86400000); start.setHours(0, 0, 0, 0);
  const windows = [];
  for (let t = start.getTime(); t < now + 86400000; t += 86400000) {
    const r = rnd(), n = r < 0.15 ? 0 : r < 0.55 ? 1 : r < 0.9 ? 2 : 3;
    const slots = [6, 10, 14, 18].sort(() => rnd() - 0.5).slice(0, n);
    for (const h of slots) windows.push([t + (h + rnd() * 0.5) * 3600000, t + (h + 2 + Math.round(rnd() * 2)) * 3600000 + rnd() * 600000]);
  }
  const isOff = (ms) => windows.some(([a, b]) => ms >= a && ms < b);

  const samples = [], outages = [], daily = {};
  let soc = 90, open = null, prev = null;
  for (let t = start.getTime(); t <= now; t += STEP) {
    const h = hmOf(t), off = isOff(t);
    const load = Math.round(140 + 160 * Math.max(0, Math.sin(((h - 6) / 18) * Math.PI)) + (h > 18 && h < 23 ? 220 : 0) + rnd() * 120);
    const pv = h > 9 && h < 15.5 ? Math.round(Math.max(0, Math.sin(((h - 9) / 6.5) * Math.PI)) * (250 + rnd() * 350)) : 0;
    let bIn = 0, bOut = 0;
    if (off) { bOut = Math.max(0, load - pv); soc = Math.max(5, soc - (bOut * STEP / 3600000 / 1000 / BATT_KWH) * 100); }
    else if (soc < 100) { bIn = Math.min(1500, ((100 - soc) / 100) * BATT_KWH * 1000 * 1.2); soc = Math.min(100, soc + (bIn * STEP / 3600000 / 1000 / BATT_KWH) * 100); }
    const s = { ts: new Date(t).toISOString(), grid_on: !off, grid_v: off ? 0 : 205 + Math.round(rnd() * 25), out_v: 220, load_w: load, pv_w: pv, grid_w: null, soc: Math.round(soc), batt_v: 50 + soc / 25, batt_in_w: Math.round(bIn), batt_out_w: Math.round(bOut), mode: off ? "Battery Mode" : "Line Mode" };
    samples.push(s);
    if (prev) {
      const dH = STEP / 3600000, d = dayOf(t);
      const x = (daily[d] ||= { day: d, grid_kwh: 0, grid_cost: 0, load_kwh: 0, pv_kwh: 0, batt_in_kwh: 0, batt_out_kwh: 0, outage_min: 0, grid_estimated: true });
      const grid = s.grid_on && prev.grid_on ? Math.max(0, load + bIn - pv) : 0;
      x.grid_kwh += grid * dH / 1000; x.grid_cost += grid * dH / 1000 * TARIFF; x.load_kwh += load * dH / 1000; x.pv_kwh += pv * dH / 1000;
      x.batt_in_kwh += bIn * dH / 1000; x.batt_out_kwh += bOut * dH / 1000; if (!s.grid_on && !prev.grid_on) x.outage_min += 5;
    }
    if (off && !open) { open = { id: outages.length + 1, started_at: s.ts, ended_at: null, soc_start: s.soc, soc_min: s.soc, soc_end: null }; outages.push(open); }
    else if (off && open) open.soc_min = Math.min(open.soc_min, s.soc);
    else if (!off && open) { open.ended_at = s.ts; open.soc_end = s.soc; open = null; }
    prev = s;
  }
  // тривоги в Києві: часто перед відключеннями і вночі
  let aid = 1;
  for (const [a] of windows) if (a < now && rnd() < 0.6) { const s = a - (0.5 + rnd()) * 3600000; alertsHist.push({ id: aid++, region: 9, started_at: new Date(s).toISOString(), ended_at: new Date(s + (40 + rnd() * 120) * 60000).toISOString(), level: "red" }); }
  alertsHist.push({ id: aid++, region: 9, started_at: new Date(now - 34 * 60000).toISOString(), ended_at: null, level: "red" });
  alertsHist.sort((x, y) => (x.started_at < y.started_at ? -1 : 1));
  const zones = { home: { label: "Київ", status: { active: true, red: true, kinds: ["Повітряна тривога"], threats: ["drones", "ballistic_missiles"], threat_names: ["дрони", "балістика"], since: new Date(now - 34 * 60000).toISOString(), near: 0 } },
    family: [{ id: 1, name: "Михайло", me: true, place: "Київ", at: new Date(now - 6 * 60000).toISOString(), src: "app", status: { active: true, red: true, kinds: ["Повітряна тривога"], threats: ["drones", "ballistic_missiles"], threat_names: ["дрони", "балістика"], since: new Date(now - 34 * 60000).toISOString(), near: 0 } },
      { id: 2, name: "Оля", me: false, place: "Крюківщина · Вишнева міська гр. · Бучанський район", at: new Date(now - 2 * 60000).toISOString(), src: "telegram", status: { active: true, red: true, kinds: ["Повітряна тривога"], threats: ["drones"], threat_names: ["дрони"], since: new Date(now - 20 * 60000).toISOString(), near: 2 } }] };
  const alertsInfo = () => ({ zones, has_token: settings.has_alerts_token, state: alertState, at: now - 40000, region: settings.alerts_region, region_name: ["АР Крим", "Волинська обл.", "Вінницька обл.", "Дніпропетровська обл.", "Донецька обл.", "Житомирська обл.", "Закарпатська обл.", "Запорізька обл.", "Івано-Франківська обл.", "м. Київ", "Київська обл.", "Кіровоградська обл.", "Луганська обл.", "Львівська обл.", "Миколаївська обл.", "Одеська обл.", "Полтавська обл.", "Рівненська обл.", "м. Севастополь", "Сумська обл.", "Тернопільська обл.", "Харківська обл.", "Херсонська обл.", "Хмельницька обл.", "Черкаська обл.", "Чернівецька обл.", "Чернігівська обл."][settings.alerts_region], open: alertsHist.find((x) => !x.ended_at) || null, error: "" });
  const lastPoints = [["AC Input Voltage", String(prev.grid_v), "V"], ["Output Voltage", "220.0", "V"], ["Battery Capacity", String(prev.soc), "%"], ["Battery Voltage", prev.batt_v.toFixed(1), "V"], ["AC Output Active Power", String(prev.load_w), "W"], ["PV Input Power", String(prev.pv_w), "W"], ["Operating mode", prev.mode, ""]];

  // ── Сімʼя (демо): Михайло — адміністратор, Оля — член сімʼї
  const members = [{ id: 1, name: "Михайло", role: "admin", phone: "+380671234567", has_tg: true, has_pass: true, created_at: new Date(now - 30 * 86400000).toISOString() }, { id: 2, name: "Оля", role: "member", phone: "+380502223344", has_tg: true, has_pass: true, created_at: new Date(now - 29 * 86400000).toISOString() }];
  const me = members[0];
  const ago = (min) => new Date(now - min * 60000).toISOString();
  let sid = 1;
  const CATS = [["Овочі й фрукти", /картопл|цибул|морк|банан|яблу|помідор|огір|лимон|зелен/], ["Молочне й яйця", /молок|кефір|сир|сметан|йогурт|яйц/], ["Хліб", /хліб|батон|лаваш/], ["М'ясо й риба", /курк|куряч|стегн|філе|фарш|ковбас|риб/], ["Бакалія", /гречк|рис|макарон|олі|кав|чай|цукор|борошн/], ["Солодке й снеки", /шоколад|печив|цукерк/], ["Напої", /вод|сік/], ["Побутове", /порош|папір|мило|губк|пакет/]];
  const catOf = (n) => (CATS.find(([, re]) => re.test(n.toLowerCase())) || ["Інше"])[0];
  const shop = [
    ["Молоко 2,5%", "Оля", 95], ["Хліб", "Оля", 95], ["Яйця, 10 шт", "Оля", 94], ["Банани", "Оля", 94], ["Огірки", "Оля", 93], ["Курячі стегна", "Оля", 93],
    ["Гречка", "Михайло", 300], ["Пральний порошок", "Оля", 92], ["Сметана", "Оля", 92], ["Батарейки АА", "Михайло", 60],
  ].map(([name, by, m]) => ({ id: sid++, name, cat: catOf(name), added_name: by, added_at: ago(m), bought_at: null, bought_name: null }));
  shop.push({ id: sid++, name: "Кава", cat: "Бакалія", added_name: "Оля", added_at: ago(600), bought_at: ago(40), bought_name: "Михайло" });
  shop.push({ id: sid++, name: "Сир твердий", cat: "Молочне й яйця", added_name: "Оля", added_at: ago(600), bought_at: ago(42), bought_name: "Михайло" });
  const freq = ["Молоко 2,5%", "Хліб", "Кефір", "Помідори", "Вода 6 л", "Яблука", "Сир кисломолочний", "Туалетний папір"];
  const td = dayOf(now), plus = (n) => dayOf(now + n * 86400000);
  const nextDow = (dow) => { for (let i = 1; i <= 7; i++) if (new Date(now + i * 86400000).getDay() === dow) return plus(i); };
  let eid = 1;
  const events = [
    { title: "Педіатр", notes: "Поліклініка, каб. 214, взяти картку", day: plus(1), tm: "15:30", rep: "none", remind: [1440, 60], who: 2 },
    { title: "Поїздка до мами", notes: "Взяти павербанки", day: nextDow(0), tm: "11:00", rep: "weekly", remind: [1440], who: null },
    { title: "Стоматолог", notes: "", day: plus(4), tm: "09:00", rep: "none", remind: [1440, 60], who: 1 },
    { title: "День народження мами", notes: "Замовити торт", day: "1962-" + plus(9).slice(5), tm: null, rep: "yearly", remind: [10080, 1440], who: null },
    { title: "Оплатити комуналку", notes: "", day: "2026-01-10", tm: null, rep: "monthly", remind: [0], who: 1 },
    { title: "Батьківські збори", notes: "Школа, 3-Б", day: plus(2), tm: "18:00", rep: "none", remind: [60], who: 2 },
  ].map((e) => ({ id: eid++, created_by: 1, ...e }));
  let pid = 1;
  const power = [{ id: pid++, title: "Увімкнути пральку", created_name: "Оля", created_at: ago(120), notified_at: null }, { id: pid++, title: "Зарядити павербанки", created_name: "Михайло", created_at: ago(300), notified_at: null }];
  const locations = [
    { who: "tg:2", member_id: null, name: "Оля", lat: 50.4423, lon: 30.5199, accuracy: 15, live_until: new Date(now + 6 * 3600000).toISOString(), source: "telegram", updated_at: ago(2) },
    { who: "m:1", member_id: 1, name: "Михайло", lat: 50.4546, lon: 30.4416, accuracy: 30, live_until: null, source: "app", updated_at: ago(85) },
  ];
  // ── Зарядка ЖК (демо): ліміт 3 кВт на під'їзд
  const sNow = () => Math.floor(Date.now() / 1000);
  let cid = 50;
  const cb = [
    { id: cid++, apartment: "12", kw: 1, start_ts: sNow() - 2400, end_ts: sNow() + 3000 },
    { id: cid++, apartment: "45", kw: 0.5, start_ts: sNow() - 900, end_ts: sNow() + 2700 },
    { id: cid++, apartment: "7", kw: 0.3, start_ts: sNow() + 3600, end_ts: sNow() + 7200 },
  ];
  let cq = null;
  const chStatus = () => {
    const t = sNow(), act = cb.filter((b) => b.start_ts <= t);
    return { registered: true, apartment: "45", entrance: 1, gen_on: true, limit: 3, load: act.reduce((a, b) => a + b.kw, 0), now: t,
      bookings: cb.map((b) => ({ ...b, mine: b.apartment === "45" })), queue: cq ? [{ ...cq, pos: 1, apartment: "45", mine: true }] : [], my_queue: cq,
      today: [{ apartment: "12", kwh: 1.4 }, { apartment: "45", kwh: 0.62 }, { apartment: "31", kwh: 0.35 }],
      kw_options: [0.1, 0.2, 0.3, 0.5, 1, 1.5, 2, 3], dur_options: [30, 60, 90, 120, 180] };
  };
  const chResp = (result) => ({ linked: true, result, status: chStatus(), family_apartment: null });
  const chargingSummary = () => { const s = chStatus(); return { gen_on: s.gen_on, load: s.load, limit: s.limit, mine: s.bookings.find((b) => b.mine) || null, my_queue: s.my_queue, now: s.now }; };

  // ── Витрати сімʼї (демо): операції Monobank за 2 місяці
  const SP = [["Сільпо", "Продукти", 300, 1400], ["АТБ", "Продукти", 150, 700], ["Uklon", "Транспорт і авто", 120, 320], ["OKKO", "Транспорт і авто", 900, 1800], ["Аптека Доброго Дня", "Здоровʼя й аптека", 90, 650], ["Пузата хата", "Кафе й ресторани", 250, 600], ["Aroma Kava", "Кафе й ресторани", 60, 140], ["Київстар", "Комуналка й звʼязок", 250, 250], ["Rozetka", "Дім і техніка", 300, 2500], ["Netflix", "Розваги й підписки", 249, 249], ["Дитячий світ", "Діти", 400, 1500], ["Novus", "Продукти", 400, 1200]];
  let txid = 1; const txns = [];
  for (let k = 0; k < 62; k++) {
    const dt = now - k * 86400000, n = 1 + Math.floor(rnd() * 3);
    for (let i = 0; i < n; i++) { const [desc, cat, a, b] = SP[Math.floor(rnd() * SP.length)]; const who = rnd() < 0.55 ? 1 : 2; txns.push({ id: "d" + txid++, ts: new Date(dt - rnd() * 36e6).toISOString(), amount: -Math.round(a + rnd() * (b - a)), currency: 980, description: desc, category: cat, hidden: false, member_id: who, comment: null, manual: false }); }
    if (k % 15 === 3) txns.push({ id: "d" + txid++, ts: new Date(dt).toISOString(), amount: -2000, currency: 980, description: "Переказ на картку Оля", category: "Перекази", hidden: false, member_id: 1, comment: null, manual: false });
  }
  txns.push({ id: "d" + txid++, ts: new Date(now - 5 * 86400000).toISOString(), amount: 42000, currency: 980, description: "Зарплата", category: "Надходження", hidden: false, member_id: 1, comment: null, manual: false });
  let monoLink = { id: 1, client_name: "Михайло", share: "full", hook_ok: true, last_sync: new Date(now - 8 * 60000).toISOString(), last_error: null, pending: 0, accounts: [{ id: "a1", label: "Чорна •1234 ₴", currency: 980, include: true }, { id: "a2", label: "Біла •9876 $", currency: 840, include: false }] };
  const CATS2 = ["Продукти", "Кафе й ресторани", "Транспорт і авто", "Здоровʼя й аптека", "Комуналка й звʼязок", "Діти", "Одяг і взуття", "Дім і техніка", "Розваги й підписки", "Подорожі", "Краса", "Тварини", "Готівка", "Інше", "Перекази", "Надходження"];
  // планер (демо)
  const dBud = [{ category: "Продукти", limit: 16000 }, { category: "Кафе й ресторани", limit: 5000 }, { category: "Транспорт і авто", limit: 4000 }, { category: "Діти", limit: 6000 }];
  let dPlans = [
    { id: 1, title: "Комуналка", kind: "expense", amount: 3200, category: "Комуналка й звʼязок", day: 15, every: "month", remind_days: 3 },
    { id: 2, title: "Інтернет Воля", kind: "expense", amount: 300, category: "Комуналка й звʼязок", day: 12, every: "month", remind_days: 2, match: "Воля" },
    { id: 3, title: "Netflix", kind: "expense", amount: 349, category: "Розваги й підписки", day: 20, every: "month", remind_days: 1 },
    { id: 4, title: "Садочок", kind: "expense", amount: 2500, category: "Діти", day: 5, every: "month", remind_days: 2 },
    { id: 5, title: "Зарплата Михайло", kind: "income", amount: 62000, day: 25, every: "month", remind_days: 0 },
    { id: 6, title: "Аванс", kind: "income", amount: 30000, day: 10, every: "month", remind_days: 0 }], dPid = 7;
  const dPaid = { 4: true, 6: true };
  let dCash = [{ cid: 1, kind: "cash", name: "Готівка вдома", owner: "Оля", balance: 4200 }], dCid = 2;
  let dGoals = [{ id: 1, title: "Відпустка влітку", target: 80000, saved: 26500, deadline: "2027-07-01", jar_id: "j1", jar: "На море" }, { id: 2, title: "Подушка безпеки", target: 150000, saved: 91000, deadline: null }], dGid = 3;
  const plannerView = (m, sp) => {
    const spentBy = {}; for (const t of sp) spentBy[t.category] = (spentBy[t.category] || 0) - t.amount;
    const budgets = dBud.map((b) => ({ ...b, spent: Math.round(spentBy[b.category] || 0) }));
    const td = dayOf(Date.now());
    const plans = dPlans.map((p) => { const due = `${m}-${String(Math.min(p.day, 28)).padStart(2, "0")}`; const paid = !!dPaid[p.id] || (m < td.slice(0, 7)); return { ...p, due, paid, auto: paid && p.id === 4, overdue: !paid && due < td }; });
    const accounts = [{ kind: "mono", name: "Чорна •1234", owner: "Михайло", balance: 23850 }, { kind: "mono", name: "Біла •5521", owner: "Оля", balance: 8120 }, ...dCash];
    const total = accounts.reduce((s, a) => s + a.balance, 0);
    const inc = plans.filter((p) => p.kind === "income" && !p.paid).reduce((s, p) => s + p.amount, 0), exp = plans.filter((p) => p.kind === "expense" && !p.paid).reduce((s, p) => s + p.amount, 0);
    const left = budgets.reduce((s, b) => s + Math.max(0, b.limit - b.spent - plans.filter((p) => !p.paid && p.kind === "expense" && p.category === b.category).reduce((x, p) => x + p.amount, 0)), 0);
    const goals = dGoals.map((g) => ({ ...g, done: g.saved >= g.target, monthly: g.deadline ? Math.ceil((g.target - g.saved) / 8) : null }));
    return { budgets, plans, accounts, jars: [{ id: "j1", title: "На море", balance: 26500, owner: "Михайло" }], total, goals, budget_total: budgets.reduce((s, b) => s + b.limit, 0),
      forecast: m === td.slice(0, 7) ? { balance: total, income: inc, planned: exp, budget_left: left, end: Math.round(total + inc - exp - left) } : null };
  };
  const moneyView = (b) => {
    const m = (b && b.month) || dayOf(Date.now()).slice(0, 7), pm = (() => { const x = new Date(m + "-01T00:00:00"); x.setMonth(x.getMonth() - 1); return dayOf(x.getTime()).slice(0, 7); })();
    const inM = (t, mm) => dayOf(Date.parse(t.ts)).slice(0, 7) === mm;
    const spend = (t) => t.amount < 0 && !t.hidden && t.category !== "Перекази";
    const rows = txns.filter((t) => inM(t, m)), sp = rows.filter(spend), sum = (xs) => xs.reduce((s, t) => s - t.amount, 0);
    const grp = (key) => { const g = {}; for (const t of sp) g[key(t)] = (g[key(t)] || 0) - t.amount; return Object.entries(g).map(([k, v]) => ({ k, v })).sort((x, y) => y.v - x.v); };
    const nm = (id) => members.find((x) => x.id === id).name;
    return { month: m, total: sum(sp), prev_total: sum(txns.filter((t) => inM(t, pm) && spend(t))), prev_same: sum(txns.filter((t) => inM(t, pm) && spend(t) && new Date(t.ts).getDate() <= new Date().getDate())), income: rows.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0),
      by_category: grp((t) => t.category), by_member: grp((t) => nm(t.member_id)), by_day: sp.reduce((o, t) => { const d = dayOf(Date.parse(t.ts)); o[d] = (o[d] || 0) - t.amount; return o; }, {}),
      txns: rows.sort((x, y) => Date.parse(y.ts) - Date.parse(x.ts)).map((t) => ({ ...t, member: nm(t.member_id), mine: t.member_id === 1 })),
      links: monoLink ? [monoLink] : [], family: members.map((x) => ({ id: x.id, name: x.name, connected: x.id === 1 ? !!monoLink : true })), categories: CATS2, now: Date.now(), planner: plannerView(m, sp) };
  };

  const shopList = () => ({ items: shop.filter((i) => !i.cleared), frequent: freq.filter((f) => !shop.some((i) => !i.bought_at && i.name.toLowerCase() === f.toLowerCase())), now: Date.now() });
  const evList = () => ({ events: [...events].sort((a, b) => (a.day + (a.tm || "")).localeCompare(b.day + (b.tm || ""))), power: power.filter((p) => !p.done), members: members.map(({ id, name }) => ({ id, name })), now: Date.now(), today: dayOf(Date.now()), light_off: false });
  const home = () => {
    const occ = window.DimOcc || (() => []);
    const t = dayOf(Date.now()), to = dayOf(Date.now() + 7 * 86400000), hmNow = `${String(new Date().getHours()).padStart(2, "0")}:${String(new Date().getMinutes()).padStart(2, "0")}`;
    const up = events.flatMap((e) => occ(e, t, to).map((d) => ({ id: e.id, title: e.title, day: d, tm: e.tm, who: e.who ? members.find((m) => m.id === e.who).name : "" })))
      .filter((o) => !(o.day === t && o.tm && o.tm < hmNow)).sort((a, b) => (a.day + (a.tm || "09:00")).localeCompare(b.day + (b.tm || "09:00"))).slice(0, 4);
    const left = shop.filter((i) => !i.bought_at && !i.cleared);
    return { charging: chargingSummary(), shop_left: left.length, shop_preview: left.slice(0, 5).map((i) => i.name), events: up, power: power.filter((p) => !p.notified_at && !p.done).map(({ id, title }) => ({ id, title })) };
  };

  // Графік ДТЕК для демо: черга 3.1
  const dtekDemo = () => {
    const t0 = new Date(); t0.setHours(0, 0, 0, 0); const d0 = dayOf(t0.getTime()), d1 = dayOf(t0.getTime() + 86400000);
    const days = [{ date: d0, status: "ScheduleApplies", slots: [{ s: 0, e: 210, t: "off" }, { s: 420, e: 870, t: "off" }, { s: 1020, e: 1290, t: "off" }] },
      { date: d1, status: "ScheduleApplies", slots: [{ s: 0, e: 240, t: "off" }, { s: 600, e: 720, t: "maybe" }, { s: 1080, e: 1320, t: "off" }] }];
    const ivs = []; for (const d of days) { const b = Date.parse(d.date + "T00:00:00"); for (const x of d.slots.filter((y) => y.t === "off")) { const l = ivs[ivs.length - 1], a = b + x.s * 60000, e = b + x.e * 60000; if (l && a - l.b <= 60000) l.b = e; else ivs.push({ a, b: e }); } }
    const n = Date.now();
    return { group: settings.dtek_group ?? "3.1", groups: Array.from({ length: 60 }, (_, i) => `${i + 1}.1`), days, updated: "", src: "yasno", at: n - 4 * 60000, error: "",
      current: ivs.find((x) => x.a <= n && x.b > n) || null, next: ivs.find((x) => x.a > n) || null, forecast: { soc: 78, load_w: 380, hours: 6.7, method: "kwh" },
      status_ua: { ScheduleApplies: "діє графік", WaitingForSchedule: "графік ще не опубліковано", EmergencyShutdowns: "екстрені відключення — графік не діє" } };
  };
  const inDays = (iso, from, to) => { const d = dayOf(Date.parse(iso)); return d >= from && d <= to; };
  const A = {
    status: () => ({ needs_setup: false }),
    login: () => ({ token: "demo" }), setup: () => ({ token: "demo" }), credentials_save: () => ({ token: "demo" }),
    dashboard: () => ({
      now: Date.now(), last: samples[samples.length - 1], open: outages.find((o) => !o.ended_at) || null,
      last_outage: [...outages].reverse().find((o) => o.ended_at) || null, today: daily[dayOf(now)] || null,
      samples: samples.filter((s) => Date.parse(s.ts) > now - 26 * 3600000).map((s) => ({ ts: s.ts, grid_on: s.grid_on, soc: s.soc, load_w: s.load_w })),
      settings, alerts: alertsInfo(), me, home: home(),
    }),
    dtek: () => ({ ...dtekDemo(), settings }),
    dtek_save: (b) => { Object.assign(settings, b.settings); return { settings }; },
    outages: (b) => {
      const f = (o) => dayOf(Date.parse(o.started_at)) <= b.to && (o.ended_at ? dayOf(Date.parse(o.ended_at)) : dayOf(now)) >= b.from;
      return { now: Date.now(), outages: outages.filter(f), alerts: alertsHist.filter(f) };
    },
    daily: (b) => ({ days: Object.values(daily).filter((d) => d.day >= b.from && d.day <= b.to) }),
    samples: (b) => ({ samples: samples.filter((s) => inDays(s.ts, b.day, b.day)) }),
    settings_save: (b) => { const v = { ...b.settings }; if (v.alerts_token) settings.has_alerts_token = true; delete v.alerts_token; Object.assign(settings, v); return { settings }; },
    members: () => ({ members, me, invites: [] }),
    invite_create: () => ({ code: "demo-invite" }), member_reset: () => ({ code: "demo-reset" }), tg_unlink: () => ({}),
    member_remove: () => { throw Object.assign(new Error("У демо-режимі не можна прибрати"), { api: true }); },
    shop_list: shopList,
    shop_add: (b) => {
      const names = String(b.text || "").split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);
      let added = 0;
      for (const raw of names) { const n = raw[0].toUpperCase() + raw.slice(1); if (shop.some((i) => !i.bought_at && !i.cleared && i.name.toLowerCase() === n.toLowerCase())) continue; shop.push({ id: sid++, name: n, cat: catOf(n), added_name: me.name, added_at: new Date().toISOString(), bought_at: null, bought_name: null }); added++; }
      return { added, ...shopList() };
    },
    shop_toggle: (b) => { const i = shop.find((x) => x.id === b.id); if (i) { if (i.bought_at) { i.bought_at = null; i.bought_name = null; } else { i.bought_at = new Date().toISOString(); i.bought_name = me.name; } } return shopList(); },
    shop_delete: (b) => { const k = shop.findIndex((x) => x.id === b.id); if (k >= 0) shop.splice(k, 1); return shopList(); },
    shop_clear: () => { shop.forEach((i) => { if (i.bought_at) i.cleared = true; }); return shopList(); },
    events_list: evList,
    event_save: (b) => {
      const e = b.event; if (!String(e.title || "").trim()) throw Object.assign(new Error("Вкажіть назву події"), { api: true });
      if (e.id) Object.assign(events.find((x) => x.id === e.id), e); else events.push({ ...e, id: eid++, created_by: 1 });
      return evList();
    },
    event_delete: (b) => { const k = events.findIndex((x) => x.id === b.id); if (k >= 0) events.splice(k, 1); return evList(); },
    power_add: (b) => { power.push({ id: pid++, title: b.title, created_name: me.name, created_at: new Date().toISOString(), notified_at: null }); return evList(); },
    power_done: (b) => { const p = power.find((x) => x.id === b.id); if (p) p.done = true; return evList(); },
    locations: () => ({ locations, now: Date.now() }),
    loc_share: (b) => { const l = locations.find((x) => x.who === "m:1"); Object.assign(l || (locations.push({ who: "m:1", member_id: 1, name: me.name, source: "app", live_until: null }), locations.at(-1)), { lat: b.lat, lon: b.lon, accuracy: b.accuracy, updated_at: new Date().toISOString() }); return { locations, now: Date.now() }; },
    loc_stop: () => { const k = locations.findIndex((x) => x.who === "m:1"); if (k >= 0) locations.splice(k, 1); return { locations, now: Date.now() }; },
    money: moneyView,
    mono_connect: () => { throw Object.assign(new Error("У демо банк не підключається"), { api: true }); },
    mono_update: (b) => { if (b.share) monoLink.share = b.share; if (b.include) monoLink.accounts.forEach((a) => (a.include = b.include.includes(a.id))); return moneyView(b); },
    mono_disconnect: (b) => { monoLink = null; return moneyView(b); },
    txn_update: (b) => { const t = txns.find((x) => x.id === b.id); if (b.delete) txns.splice(txns.indexOf(t), 1); else { if (b.category) t.category = b.category; if (b.hidden != null) t.hidden = b.hidden; } return moneyView(b); },
    weather: (key) => {
      const names = { home: "Крюківщина", dacha: "Хотянівка", kyiv: "Київ", me: "Де я зараз" }, base = Date.now() - (Date.now() % 3600000);
      const iso = (ms) => new Date(ms + 2 * 3600000).toISOString().slice(0, 16);
      const ht = Array.from({ length: 48 }, (_, i) => base + (i - 2) * 3600000);
      const temps = ht.map((t, i) => Math.round(6 + 4 * Math.sin(((new Date(t).getUTCHours() - 8) / 24) * 2 * Math.PI)));
      const days = Array.from({ length: 7 }, (_, i) => new Date(Date.now() + i * 86400000 + 2 * 3600000).toISOString().slice(0, 10));
      return { name: names[key] || "Крюківщина",
        w: { current: { temperature_2m: 7.4, apparent_temperature: 4.1, relative_humidity_2m: 81, weather_code: 3, wind_speed_10m: 14, wind_gusts_10m: 31, is_day: 1 },
          hourly: { time: ht.map(iso), temperature_2m: temps, precipitation_probability: ht.map((_, i) => (i > 12 && i < 20 ? 60 : 10)), weather_code: ht.map((_, i) => (i > 12 && i < 20 ? 61 : i % 7 ? 3 : 2)), is_day: ht.map((t) => { const h = new Date(t + 2 * 3600000).getUTCHours(); return h >= 7 && h < 17 ? 1 : 0; }) },
          daily: { time: days, weather_code: [3, 61, 63, 2, 1, 0, 71], temperature_2m_min: [3, 4, 2, 0, -1, -2, -4], temperature_2m_max: [9, 8, 6, 7, 6, 5, 1], precipitation_probability_max: [15, 70, 85, 20, 5, 0, 55],
            sunrise: days.map((d) => d + "T07:01"), sunset: days.map((d) => d + "T16:12"), shortwave_radiation_sum: [3.1, 1.4, 1.2, 4.8, 6.2, 7.1, 2.0] } },
        a: { current: { european_aqi: 34, pm2_5: 11.2, pm10: 18.5, nitrogen_dioxide: 21.4, ozone: 38 }, hourly: { european_aqi: ht.map((_, i) => (i > 20 && i < 26 ? 52 : 30)) } } };
    },
    budget_set: (b) => { const i = dBud.findIndex((x) => x.category === b.category); const a = parseFloat(String(b.amount).replace(",", ".")) || 0; if (a <= 0) { if (i >= 0) dBud.splice(i, 1); } else if (i >= 0) dBud[i].limit = a; else dBud.push({ category: b.category, limit: a }); return moneyView(b); },
    plan_save: (b) => { const p = { ...b.plan, amount: parseFloat(b.plan.amount) || 0, day: +b.plan.day || 1, remind_days: +b.plan.remind_days || 0, month: +b.plan.month || null }; if (p.id) dPlans = dPlans.map((x) => (x.id === p.id ? { ...x, ...p } : x)); else dPlans.push({ ...p, id: dPid++ }); return moneyView(b); },
    plan_delete: (b) => { dPlans = dPlans.filter((x) => x.id !== b.id); return moneyView(b); },
    plan_paid: (b) => { dPaid[b.id] = !!b.paid; return moneyView(b); },
    account_save: (b) => { const o = parseFloat(String(b.opening || "").replace(",", ".")); if (b.id) { const a = dCash.find((x) => x.cid === b.id); a.name = b.name; if (!isNaN(o)) a.balance = o; } else dCash.push({ cid: dCid++, kind: "cash", name: b.name, owner: "Михайло", balance: o || 0 }); return moneyView(b); },
    account_delete: (b) => { dCash = dCash.filter((x) => x.cid !== b.id); return moneyView(b); },
    goal_save: (b) => { const g = b.goal; if (g.id) Object.assign(dGoals.find((x) => x.id === g.id), { title: g.title, target: +g.target, deadline: g.deadline || null }); else dGoals.push({ id: dGid++, title: g.title, target: +g.target, saved: +g.saved || 0, deadline: g.deadline || null }); return moneyView(b); },
    goal_add: (b) => { const g = dGoals.find((x) => x.id === b.id); g.saved = Math.max(0, g.saved + (parseFloat(b.amount) || 0)); return moneyView(b); },
    goal_delete: (b) => { dGoals = dGoals.filter((x) => x.id !== b.id); return moneyView(b); },
    txn_add: (b) => { txns.push({ id: "d" + txid++, ts: new Date(b.day + "T12:00:00").toISOString(), amount: -Math.abs(parseFloat(String(b.amount).replace(",", "."))), currency: 980, description: b.note, category: b.category, hidden: false, member_id: 1, comment: null, manual: true }); return moneyView({ month: b.day.slice(0, 7) }); },
    tg_me_link: () => { throw Object.assign(new Error("У демо Telegram не підключається"), { api: true }); },
    charging: (b) => {
      const op = b.op || "status", t = sNow(), err = (m) => { throw Object.assign(new Error(m), { api: true }); };
      if (op === "status") return chResp(null);
      if (op === "book") {
        if (cb.some((x) => x.apartment === "45")) err("У вашої квартири вже є бронь або місце в черзі");
        const st = t + (b.start_min || 0) * 60, load = cb.filter((x) => x.start_ts < st + b.dur_min * 60 && x.end_ts > st).reduce((a, x) => a + x.kw, 0);
        if (load + b.kw > 3) return chResp({ booked: false, can_queue: !b.start_min, alt: cb[0].end_ts, reason: `Зайнято ${load} з 3 кВт.` });
        cb.push({ id: cid++, apartment: "45", kw: b.kw, start_ts: st, end_ts: st + b.dur_min * 60 }); return chResp({ booked: true });
      }
      if (op === "queue_join") { cq = { id: 900, kw: b.kw, dur: b.dur_min * 60, status: "waiting", offer_until: null, pos: 1 }; return chResp({ queued: true, status: "waiting", pos: 1 }); }
      if (op === "q_leave") { cq = null; return chResp({ left: true }); }
      if (op === "done") { const k = cb.findIndex((x) => x.id === b.id); const fut = cb[k].start_ts > t; cb.splice(k, 1); return chResp({ closed: fut ? "cancelled" : "done" }); }
      if (op === "extend") { const x = cb.find((y) => y.id === b.id); x.end_ts = Math.max(x.end_ts, t) + b.min * 60; return chResp({ end_ts: x.end_ts }); }
      return chResp(null);
    },
    dess_connect: () => ({ device: "PARADISE", sn: settings.dess_sn, devices: 1 }),
    poll_now: () => ({ result: { ok: true } }),
    points: () => ({ points: lastPoints }),
    tg_link: () => { throw Object.assign(new Error("У демо-режимі Telegram недоступний"), { api: true }); },
  };
  window.DemoBackend = {
    weather: async (key) => A.weather(key),
    async call(action, body) {
      const fn = A[action]; if (!fn) return { ok: false, error: "Невідома дія" };
      try { return { ok: true, ...JSON.parse(JSON.stringify(fn(body || {}))) }; }
      catch (e) { return { ok: false, error: e.api ? e.message : "Помилка" }; }
    },
  };
})();
